function y = SVM_sample_observations(phi,sigma2,beta2,T)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUTS: 
%   beta2, sigma2, phi    - Parameters of the stochastic volatility model
%                           X_{t+1} = \phi*X_t + \sigma*U_{t+1}
%                           Y_{t}   = \exp{X_t/2}*\beta*V_t
%                           where U_t and V_t are independent standard gaussian
%                           random variables (independent from X_0).
%   T                     - Number of time steps.
%
% OUTPUTS:
%   y                     - T observations sampled from the stochastic
%                           volatility model.
y       = zeros(1,T);
var0    = sigma2/(1-phi*phi);
x       = sqrt(var0)*randn(1,1);
V       = sqrt(beta2)*randn(1,T);
U       = sqrt(sigma2)*randn(1,T-1);
y(1)    = exp(x/2)*V(1);
for i=1:T-1
    x      = phi*x + U(i);
    y(i+1) = exp(x/2)*V(i+1); 
end