function [newxi,w] = SVM_sample_prior_kernel(xi,phi,sigma2,beta2,y)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUTS: 
%   xi                    - Particles at previous time step.
%   beta2, sigma2, phi    - Parameters of the stochastic volatility model
%                           X_{t+1} = \phi*X_t + \sigma*U_{t+1}
%                           Y_{t}   = \exp{X_t/2}*\beta*V_t
%                           where U_t and V_t are independent standard gaussian
%                           random variables (independent from X_0).
%   y                     - Current observation to compute the incremental
%                           weight.
%
% OUTPUTS:
%   newxi - Particles at the next time step.
%   w     - Incremental weights of these new particles.

N     = length(xi);
U     = sqrt(sigma2)*randn(1,N)'; 
newxi = phi*xi + U;
logw  = -0.5*(newxi + y*y*exp(-newxi)/beta2);
w     = exp(logw);
w     = w/sum(w);