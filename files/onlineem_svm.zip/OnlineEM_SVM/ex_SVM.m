% ex_SVM   Script for the estimation of a SVM model with
%          the Block online EM algorithm;


% Parameters
phi_sim    = 0.95;
sigma2_sim = 0.1;
beta2_sim  = 0.6;

% Initial guess
phi_0    = 0.1;
sigma2_0 = 0.6;
beta2_0  = 2;

alpha = 0.55;
b     = alpha/(1-alpha);
a     = (b+1)^(-b);

sizeblocks    = floor(0.5*(30:1:350).^b);
Nobservations = sum(sizeblocks);
sumsizeblocks = cumsum(sizeblocks);
p             = length(sizeblocks);

phi_est             = zeros(1,p+1); 
sigma2_est          = zeros(1,p+1); 
beta2_est           = zeros(1,p+1);

phi_est_mean        = zeros(1,p+1);
sigma2_est_mean     = zeros(1,p+1);
beta2_est_mean      = zeros(1,p+1);

phi_est(1)          = phi_0;
sigma2_est(1)       = sigma2_0;
beta2_est(1)        = beta2_0;
phi_est_mean(1)     = phi_0;
sigma2_est_mean(1)  = sigma2_0;
beta2_est_mean(1)   = beta2_0;

Sxx_mean            = 0;
Sxy_mean            = 0;
Sx2_1_mean          = 0;
Sx2_2_mean          = 0;

Y = SVM_sample_observations(phi_sim,sigma2_sim,beta2_sim,Nobservations);

tic;
for i=1:p
    i
    if i==1
        Y_block       = Y(1:sumsizeblocks(1));
    else
        Y_block       = Y(sumsizeblocks(i-1)+1:sumsizeblocks(i));
    end
    l        = sizeblocks(i);
    sumblock = sumsizeblocks(i);
    gamma    = (1:l).^(-1);
    [Sxx_a, Sxy_a, Sx2_1_a, Sx2_2_a] = onlinebloc_SVM(Y_block,phi_est(i),sigma2_est(i),beta2_est(i),gamma,max(floor(l/6),15));
    if i<=150
        Sxx_mean   = Sxx_a;
        Sxy_mean   = Sxy_a;                      
        Sx2_1_mean = Sx2_1_a;                     
        Sx2_2_mean = Sx2_2_a;
    end
    if i>150
        sumblock   = sumsizeblocks(i) - sumsizeblocks(150);
        Sxx_mean   = (1-l/sumblock)*Sxx_mean   + l*Sxx_a/sumblock;
        Sxy_mean   = (1-l/sumblock)*Sxy_mean   + l*Sxy_a/sumblock;
        Sx2_1_mean = (1-l/sumblock)*Sx2_1_mean + l*Sx2_1_a/sumblock;
        Sx2_2_mean = (1-l/sumblock)*Sx2_2_mean + l*Sx2_2_a/sumblock;
    end

    [phi_est(k,i+1), sigma2_est(k,i+1), beta2_est(k,i+1)] = m_SVM(Sxx_a,Sxy_a,Sx2_1_a,Sx2_2_a);
    [phi_est_mean(k,i+1), sigma2_est_mean(k,i+1), beta2_est_mean(k,i+1)] = m_SVM(Sxx_mean,Sxy_mean,Sx2_1_mean,Sx2_2_mean);
end
elapsed_time = toc 

figure
plot(sumsizeblocks,phi_est(2:end))
hold on
plot(sumsizeblocks,phi_est_mean(2:end),'*')

figure
plot(sumsizeblocks,sigma2_est(2:end),'r')
hold on
plot(sumsizeblocks,sigma2_est_mean(2:end),'r*')

figure
plot(sumsizeblocks,beta2_est(2:end),'k')
hold on
plot(sumsizeblocks,beta2_est_mean(2:end),'k*')