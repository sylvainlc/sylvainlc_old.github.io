function [phi, sigma2, beta2] = m_SVM(Sxx,Sxy,Sx2_1,Sx2_2)
phi    = Sxx/Sx2_1;
sigma2 = Sx2_2 + phi*phi*Sx2_1 - 2*phi*Sxx;
beta2  = Sxy;
