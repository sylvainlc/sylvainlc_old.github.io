function [newxi,neww,Sxx,Sxy,Sx2_1,Sx2_2] = ...
  e_SVM(Y,xi,w,Sxx,Sxy,Sx2_1,Sx2_2,phi,sigma2,beta2,gam,N)

% Filtering update
idx          = mxDiscreteRand(w,N);
selectxi     = xi(idx);
[newxi,neww] = SVM_sample_prior_kernel(selectxi,phi,sigma2,beta2,Y);

% Retrospective kernel
stockpxx   = exp(-0.5*(newxi*ones(1,N)-phi*ones(N,1)*xi').*(newxi*ones(1,N)-phi*ones(N,1)*xi')/sigma2);
r          = (ones(N,1)*w').*stockpxx;
normalizer = r*ones(N,1);
r          = r./(normalizer*ones(1,N));

% Statistics update
Sxx   = (gam*newxi).*(r*xi) + (1-gam)*r*Sxx; 
Sxy   = gam*Y*Y*exp(-newxi) + (1-gam)*r*Sxy;
Sx2_1 = r*(gam*(xi.*xi)+(1-gam)*Sx2_1);
Sx2_2 = gam*(newxi.*newxi) + (1-gam)*r*Sx2_2;

