function [Sxx_a, Sxy_a, Sx2_1_a, Sx2_2_a] = onlinebloc_SVM(Y, phi, sigma2, beta2, gam,N)
% Dimensions
n = length(Y);

[xi,w] = SVM_init_sample(phi,sigma2,beta2,Y(1),N);

% Initial statistics
Sxy   = Y(1)*Y(1)*exp(-xi);
Sxx   = zeros(N,1);
Sx2_1 = zeros(N,1);
Sx2_2 = zeros(N,1);

for k = 2:n
    [xi,w,Sxx,Sxy,Sx2_1,Sx2_2] = ...
    e_SVM(Y(k),xi,w,Sxx,Sxy,Sx2_1,Sx2_2,phi,sigma2,beta2,gam(k-1),N);
end

Sxx_a   = Sxx'*w;
Sxy_a   = Sxy'*w;
Sx2_1_a = Sx2_1'*w;
Sx2_2_a = Sx2_2'*w;