% Script used to compute smoothed additive functionals with different methods
%                   - The genealogical tree method
%                   - The forwardffbs method
%                   - The fast ffbsi method

% We compute \frac{1}{T}\sum_{t=1}^{T}E[X_{t}|Y_{0:T}].

% Parameters of the linear Gaussian model.
phi       = 0.9;
sigmau    = 0.2;
sigmav    = 1;

% Number of observations.
T          = 1000;
Y          = LGM_sample_observations(phi,sigmau,sigmav,T);

%Number of particles.
N    = 50;
% Number of simulations
Nsim = 10;

% Compute the true value using the kalman smoother.
[filt_m filt_var smooth_m smooth_var smooth_cov]  = kalman_filter_smoother(phi,sigmau,sigmav,Y,T);
truevalue  = sum(smooth_m)/T;


smoothed_genealogical = LGM_smoothing_genealogical(phi,sigmau,sigmav,N,Y,Nsim);
smoothed_forwardffbs  = LGM_smoothing_forwardffbs(phi,sigmau,sigmav,N,Y,Nsim);
smoothed_ffbsi        = LGM_smoothing_ffbsi(phi,sigmau,sigmav,N,Y,Nsim);