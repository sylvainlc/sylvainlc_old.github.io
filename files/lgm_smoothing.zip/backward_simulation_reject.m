function [path] = backward_simulation_reject(xi,w,kernel,phi,sigma2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUTS:
%   xsi   - Matrix of particles obtained with the forward pass. 
%   w     - Matrix of weights obtained with the forward pass.
%   kernel([xsi_t],[xsi_t+1], theta)
%         - Returns the unnormalized quantities q(xi_t+1|xi_t);
%
% OUPUTS:
%   path                 - Matrix of N unweighted sampled paths;

[N,T]       = size(xi);
path        = zeros(N,T);
idx         = mxDiscreteRand(w(:,T),N);
path(:,T)   = xi(idx,T);
Nmin        = N/10;
for time = T-1:-1:1
    L   = 1:N;
    num = N; 
    while num > 0
        if num>Nmin
            idx              = mxDiscreteRand(w(:,time),num);
            U                = rand(num,1);
            bound            = kernel(xi(idx,time),path(L,time+1),phi,sigma2);
            ok               = find( U <= bound' );
            path(L(ok),time) = xi(idx(ok),time);
            L                = L( U > bound' );
            num              = length(L);
        else
            bigidx           = mxDiscreteRand(w(:,time),N);
            k                = 1;
            while (num>0&&k+num<=N)
                idx              = bigidx(k:k+num-1);
                k                = k+num;
                U                = rand(num,1);
                bound            = kernel(xi(idx,time),path(L,time+1),phi,sigma2);
                ok               = find( U <= bound' );
                path(L(ok),time) = xi(idx(ok),time);
                L                = L( U > bound' );
                num              = length(L);
            end
        end
    end
end