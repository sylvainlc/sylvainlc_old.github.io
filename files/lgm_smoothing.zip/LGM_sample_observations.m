function y = LGM_sample_observations(phi,sigmau,sigmav,T)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUTS: 
%   sigmau, sigmav, phi   - Parameters of the linear gaussian model
%                           X_{t+1} = \phi*X_t + \sigma_u*U_{t+1}
%                           Y_{t}   = X_t + \sigma_v*V_t
%                           where U_t and V_t are independent standard gaussian
%                           random variables (independent from X_0).
%   T                     - Number of time steps.
%
% OUTPUTS:
%   y                     - T observations sampled from the linear Gaussian
%                           model.
y    = zeros(1,T);
varu = sigmau*sigmau;
var0 = varu/(1-phi*phi);
x    = sqrt(var0)*randn(1,1);
V    = sigmav*randn(1,T);
U    = sigmau*randn(1,T-1);
y(1) = x + V(1);
for i=1:T-1
x      = phi*x + U(i);
y(i+1) = x+V(i+1); 
end
end