function kernel = LGM_normalized_markov_kernel(xi,newxi,phi,sigma)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUTS: 
%   sigmav, phi           - Parameters of the linear gaussian model
%                           X_{t+1} = \phi*X_t + \sigma_u*U_{t+1}
%                           Y_{t}   = X_t + \sigma_v*V_t
%                           where U_t and V_t are independent standard gaussian
%                           random variables (independent from X_0).
%   xi                    - Particles at time t-1.
%   newxi                 - Particles at time t.
%
% OUTPUTS:
%   kernel                - Matrix of transition probabilities between xi
%                           and newxi.
var    = sigma*sigma;
vect   = newxi-phi*xi;
kernel = exp(-0.5 * vect.*vect/var)';