function smoothed_ffbsi = LGM_smoothing_ffbsi(phi,sigmau,sigmav,Narray,Y,Nsim)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUTS: 
%   sigmau, sigmav, phi   - Parameters of the linear Gaussian model
%                           X_{t+1} = \phi*X_t + \sigma_u*U_{t+1}
%                           Y_{t}   = X_t + \sigma_v*V_t
%                           where U_t and V_t are independent standard Gaussian
%                           random variables (independent from X_0).
%   Narray                - Array giving different number of particles to use.
%   Y                     - Set of observations.
%   Nsim                  - Number of simulations.

%
% OUTPUTS:
%   smoothed_ffbsi - Smoothed value of a given additive functional (here, the empirical mean). 
%                    computed with the fast ffbsi method. 
T                  = length(Y);
smoothed_ffbsi     = zeros(size(Narray,2),Nsim);

for i=1:size(Narray,2)
    N     = Narray(i);
    pathX = zeros(N,T);
    pathw = zeros(N,T);
    for l=1:Nsim
        tic;
        %Initial particles sampled from the stationary distribution.
        [X w]      = LGM_init_sample_stat(phi,sigmau,sigmav,Y(1),N);
        pathX(:,1) = X;
        pathw(:,1) = w;
        k          = 2;
        while k<=T
            idx        = mxDiscreteRand(w,N);
            X          = X(idx);
            [X w]      = LGM_sample_prior_kernel(X,phi,sigmau,sigmav,Y(k));
            pathX(:,k) = X;
            pathw(:,k) = w;
            k          = k+1;
        end
        % Backward simulation procedure. Draws N unweighted trajectories.
        backwardparticles       = backward_simulation_reject(pathX,pathw,@LGM_normalized_markov_kernel,phi,sigmau);
        % Estimation of the smoothed empirical mean.
        S                       = sum(backwardparticles,2)/T;
        smoothed_ffbsi(i,l)     = sum(S)/N;
    end
end