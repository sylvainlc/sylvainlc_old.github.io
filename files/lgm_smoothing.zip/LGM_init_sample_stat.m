function [xi w] = LGM_init_sample_stat(phi,sigmau,sigmav,y,N)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUTS: 
%   sigmau, sigmav, phi   - Parameters of the linear Gaussian model
%                           X_{t+1} = \phi*X_t + \sigma_u*U_{t+1}
%                           Y_{t}   = X_t + \sigma_v*V_t
%                           where U_t and V_t are independent standard Gaussian
%                           random variables (independent from X_0).
%   y                     - Current observation to compute the initial
%                           weight.
%   N                     - Number of particles.
%
% OUTPUTS:
%   xi    - Particles at the first time step.
%   w     - Weights of these new particles.

varu  = sigmau*sigmau;
varv  = sigmav*sigmav;
% Initial variance (i.e variance of the stationary distribution).
var0  = varu/(1-phi*phi);

% In this linear gaussian model, the kalman filter allows to compute
% exactly the optimal proposal distribution p(x_{t+1}|x_t,y_{t+1}).
% K is the Kalman gain.

xi = sqrt(var0)*randn(1,N)';
w  = exp(-0.5*(xi-y).*(xi-y)/varv);
w  = w/sum(w);