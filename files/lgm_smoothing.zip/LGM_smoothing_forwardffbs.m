function smoothed_forwardffbs = LGM_smoothing_forwardffbs(phi,sigmau,sigmav,Narray,Y,Nsim)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUTS: 
%   sigmau, sigmav, phi   - Parameters of the linear Gaussian model
%                           X_{t+1} = \phi*X_t + \sigma_u*U_{t+1}
%                           Y_{t}   = X_t + \sigma_v*V_t
%                           where U_t and V_t are independent standard Gaussian
%                           random variables (independent from X_0).
%   Narray                - Array giving different number of particles to use.
%   Y                     - Set of observations.
%   Nsim                  - Number of simulations.

%
% OUTPUTS:
%   smoothed_forwardffbs - Smoothed value of a given additive functional (here, the empirical mean). 
%                          computed with the forward ffbs method. 
varu                     = sigmau*sigmau;
T                        = length(Y);
smoothed_forwardffbs     = zeros(size(Narray,2),Nsim);

for i=1:size(Narray,2)
    N = Narray(i);
    for l=1:Nsim
        tic;
        %Initial particles sampled from the stationary distribution.
        [X w]  = LGM_init_sample_stat(phi,sigmau,sigmav,Y(1),N);
        alpha  = X';
        k      = 2;
        while k<=T
            idx         = mxDiscreteRand(w,N);
            oldw        = w;
            oldX        = X;
            oldalpha    = alpha;
            X           = X(idx);
            [X w]       = LGM_sample_prior_kernel(X,phi,sigmau,sigmav,Y(k));
            diff        = X*ones(1,N) - phi*ones(N,1)*oldX';
            pxx         = exp(-0.5*diff.*diff/varu);
            normalizer  = pxx*oldw;
            walpha      = oldw'.*oldalpha;
            alpha       = (walpha*pxx')./normalizer' + X';
            k = k+1;
        end
        smoothed_forwardffbs(i,l)     = alpha*w/T;
    end
end