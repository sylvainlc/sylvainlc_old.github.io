#include <math.h>
#include "mex.h"

/* Input Arguments */

#define	omega	prhs[0]
#define n		prhs[1]


/* Output Arguments */

#define	var		plhs[0]

#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif


void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
{
	mwSize Nprob;
	int nNum,i,iMin,iMax,*sigma,index,tempsig,l,r,d,m;
	double *qPr,*omegaPr,*varPr,*tempPr,*UPr,*orderU;
	mxArray **temp,**unif;
	
	if (nrhs != 2) { 
	mexErrMsgTxt("Two input arguments required."); 
    } else if (nlhs > 1) {
	mexErrMsgTxt("Too many output arguments."); 
    } else if ( !mxIsNumeric(omega) )
	mexErrMsgTxt("The first input must be a numeric array");
	else if ( !mxIsNumeric(n) )
	mexErrMsgTxt("The second input must be a numeric array");
	
	Nprob = MAX( mxGetM(omega), mxGetN(omega) );
	nNum = (int)(mxGetPr(n))[0];
	
	// qPr = cumsum(omega)/sum(omega)
	qPr = mxMalloc( Nprob*sizeof(double) );
	omegaPr = mxGetPr(omega);
	qPr[0] = omegaPr[0];
	for( i=1; i<Nprob; i++ )
		qPr[i] = qPr[i-1]+omegaPr[i];
	for( i=0; i<Nprob; i++ )
		qPr[i] /= qPr[Nprob-1];

	
	// Simulation of 2n uniform rand var
	temp = mxMalloc( 2*sizeof(mxArray*));
	temp[0] = mxCreateDoubleScalar( 2*nNum );
	temp[1] = mxCreateDoubleScalar(1);
	unif = mxMalloc( 1*sizeof(mxArray*));
	mexCallMATLAB( 1, unif, 2, temp, "rand" );
	UPr = mxGetPr(unif[0]);
	mxDestroyArray(temp[0]);
	mxDestroyArray(temp[1]);
	mxFree(temp);
	
	// Sample an order statistics
	orderU = mxMalloc( (nNum+1)*sizeof(double) );
	orderU[0] = -log(UPr[0]);
	for( i=1; i<nNum+1; i++ )
		orderU[i] = orderU[i-1]-log(UPr[i]);
	for( i=0; i<nNum+1; i++ )
		orderU[i] /= orderU[nNum];

	// Uniformly sample a permutation on 1,...,n
	sigma = mxMalloc( nNum*sizeof(int) );
	for( i=0; i<nNum; i++ )
		sigma[i] = i+1;
	for( i=nNum-1; i>=1; i-- )
	{
		index = (int)( (i+1)*UPr[nNum+i] );
		tempsig = sigma[i];
		sigma[i] = sigma[index];
		sigma[index] = tempsig;
	}
	mxDestroyArray(unif[0]);
	mxFree(unif);

	var = mxCreateDoubleMatrix( nNum, 1, mxREAL );
	varPr = mxGetPr(var);

	l = 0;
	r = 1;
	for( i=1; i<=nNum; i++ )
	{
		d = 2;
		while( orderU[i-1] >= qPr[r-1] )
		{
			l = r;
			r = MIN(r+d,Nprob);
			d *= 2;
		}
		while( r-l > 1 )
		{
			m = (int)( (l+r)/2 );
			if( orderU[i-1] >= qPr[m-1] )
				l = m;
			else
				r = m;
		}
		varPr[sigma[i-1]-1] = r;
	}

	mxFree(qPr);
	mxFree(sigma);
	mxFree(orderU);
	
	return;
}