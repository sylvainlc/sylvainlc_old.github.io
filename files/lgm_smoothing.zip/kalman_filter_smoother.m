function [filt_m filt_var smooth_m smooth_var smooth_cov] = kalman_filter_smoother(phi,sigmau,sigmav,Y,T)
% Kalman filter
vartildepath   = zeros(1,T-1);
mutildepath    = zeros(1,T-1);
filt_m         = zeros(1,T);
filt_var       = zeros(1,T);
smooth_m       = zeros(1,T);
smooth_var     = zeros(1,T);
smooth_cov     = zeros(1,T-1);
varu           = sigmau*sigmau;
varv           = sigmav*sigmav;

var0           = varu/(1-phi*phi);
K              = var0/(varv + var0);
mu             = K*Y(1);
var            = (1-K)*var0;
filt_m(1)      = mu;
filt_var(1)    = var;


for i=1:T-1
    mutilde          = phi*mu;    
    vartilde         = phi*phi*var + varu;
    vartildepath(i)  = vartilde;
    mutildepath(i)   = mutilde;
    K                = vartilde/(vartilde+varv);
    mu               = mutilde + K*(Y(i+1)-mutilde);
    var              = (1-K)*vartilde;
    filt_m(i+1)      = mu;
    filt_var(i+1)    = var;
end

% Rauch-Tung-Striebel algorithm
smooth_m(T)   = filt_m(T);
smooth_var(T) = filt_var(T);
KK            = (phi*phi*filt_var(T-1)+varu)/(varv+varu+phi*phi*filt_var(T-1));
smooth_cov(T) = phi*(1-KK)*filt_var(T-1);
for i=T-1:-1:2
    F               = (1 - varu/vartildepath(i))/phi;
    K               = varu/(phi*vartildepath(i));
    smooth_m(i)     = F*smooth_m(i+1) + K*mutildepath(i);
    V               = filt_var(i)*phi*phi + varu;
    Jt              = phi*filt_var(i)/V;
    smooth_var(i)   = filt_var(i) + Jt*Jt*(smooth_var(i+1)-V);
    V               = filt_var(i-1)*phi*phi + varu;
    J               = phi*filt_var(i-1)/V;
    smooth_cov(i)   = filt_var(i)*J + Jt*(smooth_cov(i+1)-phi*filt_var(i))*J;
end
F               = (1 - varu/vartildepath(1))/phi;
K               = varu/(phi*vartildepath(1));
smooth_m(1)     = F*smooth_m(i+1) + K*mutildepath(1);
V               = filt_var(1)*phi*phi + varu;
Jt              = phi*filt_var(1)/V;
smooth_var(1)   = filt_var(1) + Jt*Jt*(smooth_var(2)-V);
