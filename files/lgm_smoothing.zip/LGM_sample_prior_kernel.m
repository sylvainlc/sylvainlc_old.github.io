function [newxi w] = LGM_sample_prior_kernel(xi,phi,sigmau,sigmav,y)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUTS: 
%   xi                    - Particles at previous time step.
%   sigmau, sigmav, phi   - Parameters of the linear Gaussian model
%                           X_{t+1} = \phi*X_t + \sigma_u*U_{t+1}
%                           Y_{t}   = X_t + \sigma_v*V_t
%                           where U_t and V_t are independent standard Gaussian
%                           random variables (independent from X_0).
%   y                     - Current observation to compute the incremental
%                           weight.
%
% OUTPUTS:
%   newxi - Particles at the next time step.
%   w     - Incremental weights of these new particles.

N     = length(xi);
varv  = sigmav*sigmav;
U     = sigmau*randn(1,N)'; 
newxi = phi*xi + U;
logw  = -0.5*(newxi-y).*(newxi-y)/varv;
w     = exp(logw);
w     = w/sum(w);