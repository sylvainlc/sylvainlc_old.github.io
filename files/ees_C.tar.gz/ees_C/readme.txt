Equi-Energy Sampler,  Adaptive Equi-Energy Sampler, etc...
Samplers for a mixture of Gaussians


What is in this file :


1) Examples :


Master function : "sampling.m"   -> call the main function with an example of input arguments




2) Code :


MH.c -> Metropolis-Hastings sampler
EES.c -> Equi-Energy Sampler
AEES.c -> Adaptive Equi-Energy Sampler
SAAEES.c -> Stochastic Approximation Adaptive Equi-Energy Sampler