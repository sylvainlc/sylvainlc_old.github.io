/*=================================================================
 *
 * Stochastic Approximation Adaptive Equi-Energy Sampler for a mixture of Gaussians
 * 
 * 
 * See sampling.m for an example of use
 * 
 * Command to run before using the function in matlab/octave:
 * mex -v -lgsl -lgslcblas SAAEES.c 
 *
 *=================================================================*/
 
 
/* libraries */
#include <math.h>
#include <gsl/gsl_rng.h>
#include "mex.h"
#include <sys/time.h>

/* random number generator */
gsl_rng * r; 

/* global variables */
int initialSize, burnInSize;
int d, Nmax, nbProcessus, nbStrates;
double *paramCible, *frontieresNonAdapt, *X, *T, *sqrtGamma, *FRONT, *constAS, *nbInit;
double epsilon;

/* Input Arguments -- see sampling.m for details */
#define	paramCible_IN prhs[0]
#define	T_IN prhs[1]
#define frontieres_IN prhs[2]
#define Nmax_IN prhs[3]
#define sqrtGamma_IN prhs[4]
#define epsilon_IN prhs[5]
#define constAS_IN prhs[6]
#define nbInit_IN prhs[7]

/* Output Arguments -- see sampling.m for details */
#define	X_OUT plhs[0]
#define	FRONT_OUT plhs[1] 

/* miscellaneous definitions, in case of */
#if !defined(PI)
#define PI 3.14159265358979323846
#endif

#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif


/* Gaussian sampler */	
double
gsl_ran_gaussian (const gsl_rng * r)
{
  double x, y, r2;

  do
    {
      /* choose x,y in uniform square (-1,-1) to (+1,+1) */

      x = -1 + 2 * gsl_rng_uniform (r);
      y = -1 + 2 * gsl_rng_uniform (r);

      /* see if it is in the unit circle */
      r2 = x * x + y * y;
    }
  while (r2 > 1.0 || r2 == 0);

  /* Box-Muller transform */
  return y * sqrt (-2.0 * log (r2) / r2);
}




/* log value of the target distribution at the temperature t */
double logPiCible(double* Y, int n, double t){
	/* variables declaration */
	int i, j;
	double res = 0, tmp;
	/* parameters of the target distribution */
	int nbGaussian = (int)(paramCible[0]);
	double* poids = &(paramCible[1]);
	double* mu = &(paramCible[1+nbGaussian]);
	double* sig2 = &(paramCible[1+nbGaussian+nbGaussian*d]);
	
	/* computation of pi */
	for (i=0; i<nbGaussian; i++){
		tmp = 0;
		for(j=0; j<d; j++){
			tmp += (Y[j+n*d]-mu[j+i*d])*(Y[j+n*d]-mu[j+i*d]);
		}
		res += poids[i]/(pow(2*PI*sig2[i],(double)d/2)) * exp(-0.5*tmp/sig2[i]);
	}
	return log(res)/t;
}


/* symmetric random walk Metropolis-Hasting */
void srwm(double* Y, int n, double t, int** nbAccRejHM, int indProcessus){
	int i,j;
	double* z;
	z = malloc(d * sizeof(double));
	for (i=0; i<d; i++) z[i] = gsl_ran_gaussian(r);
	for (i=0; i<d; i++){
		Y[i+ d*n] = Y[i + d*(n-1)]; 
		for (j=0; j<d; j++) 
			Y[i + d*n] += sqrt(t)*sqrtGamma[i + d*j]*z[j]; 
	}
	free(z);
	nbAccRejHM[indProcessus][0] += 1;
	if (log(gsl_rng_uniform(r)) > logPiCible(Y, n, t) - logPiCible(Y, n-1, t)){
		for (i=0; i<d; i++) Y[i + d*n] = Y[i + d*(n-1)];	
		nbAccRejHM[indProcessus][0] -= 1;
		nbAccRejHM[indProcessus][1] += 1;
	}
}



/* main function */
void equiSampler(){
	
    
    
	/* -------------- variables declaration --------- */
	
	
	int indProc, n, indDim, i, j, level, strate, indAux;
    double aux;
	double** Y;
    double** logPiOfY;
	
    int** nbAccRejHM;
    nbAccRejHM = malloc(nbProcessus * sizeof(int*));
    for (i=0; i<nbProcessus; i++){
		nbAccRejHM[i] = malloc(2 * sizeof(int));
		nbAccRejHM[i][0]=0;
		nbAccRejHM[i][1]=0;
	}
	
	int** nbAccRejJump;
    nbAccRejJump = malloc(nbProcessus * sizeof(int*));
    for (i=0; i<nbProcessus; i++){
		nbAccRejJump[i] = malloc(2 * sizeof(int));
		nbAccRejJump[i][0]=0;
		nbAccRejJump[i][1]=0;
	}
	
    
	Y = malloc(nbProcessus * sizeof(double*));
	logPiOfY = malloc(nbProcessus * sizeof(double*));
	
	/* speed for stochastic estimation of ring bounds */
    double vitesse = 0.51;
    
    
    double** frontieres;
    double** frontieresMoy;
    int* tabIndAux;
    int nbIndAux=0, levelAux;
    
    tabIndAux = malloc((Nmax + nbProcessus*initialSize) * sizeof(int));
    frontieres = malloc(nbProcessus * sizeof(double*));
    frontieresMoy = malloc(nbProcessus * sizeof(double*));
    
    for (i=0; i<(nbProcessus);i++){
		frontieres[i] = malloc((nbStrates - 1) * sizeof(double));
		frontieresMoy[i] = malloc((nbStrates - 1) * sizeof(double));
    }
    

	for (indProc=0; indProc<nbProcessus; indProc++){
		Y[indProc] = malloc(d * (Nmax + nbProcessus*initialSize) * sizeof(double));
		logPiOfY[indProc] = malloc( (Nmax + nbProcessus*initialSize)  * sizeof(double));
	}
	
	
	/* --------- initialization ---------------- */
	
	
	for (j=0; j<nbProcessus;j++){
		for (i=0; i<(nbStrates-1); i++){
			frontieres[j][i] = frontieresNonAdapt[i]; 
			frontieresMoy[j][i] = frontieres[j][i];
		}
	}
	
	
	for (indProc=0; indProc< nbProcessus; indProc++){
        
		/* initialization of the chains */
		for (indDim=0; indDim < d; indDim++){
			Y[indProc][indDim + (indProc*initialSize)*d] = -2.1;
		}
		/* value of pi for the random states */
		logPiOfY[indProc][indProc*initialSize] = logPiCible(Y[indProc],indProc*initialSize,1.0);
	}
	
	
            
	/* ----------- run ------------------------- */
	

	
	for (n=1; n<(Nmax + nbProcessus*initialSize); n++){
		
		/* --- very hot process --- */
		
		/* sample of the new state */
		srwm(Y[0], n, T[0], nbAccRejHM, 0);
		/* energy */
		logPiOfY[0][n] = logPiCible(Y[0],n,1.0);

		
		/* updating the ring bounds */
		for (i=0; i<(nbStrates-1); i++){
            aux = (double)(i+1)/nbStrates;
			frontieres[0][i] = frontieres[0][i] + constAS[0]*pow((n+1),-vitesse) * (aux - ((logPiOfY[0][n])<= frontieres[0][i]));
			frontieresMoy[0][i] = frontieresMoy[0][i] -  (frontieresMoy[0][i] - frontieres[0][i])/(n+1);
		}
		
		
		
		/* --- other processes --- */
		for (indProc=1; indProc< nbProcessus; indProc++){
			if (n>indProc*initialSize) 
			{ 
				/* sampling the new state */
				if (gsl_rng_uniform(r)>epsilon)
				{
					srwm(Y[indProc], n, T[indProc],nbAccRejHM, indProc);
				}
                else{
					/* updating the acceptation-rejection counter */
					nbAccRejJump[indProc][0] += 1;
					level=0;
					while (logPiOfY[indProc][n-1]>frontieresMoy[indProc-1][level] && level<(nbStrates-1)) 
					{
						level++;
					}
					nbIndAux=0;
					/* searching for index of states in the same level as current state */
					for (i=(indProc-1)*initialSize+burnInSize; i<n; i++)
					{
						levelAux =0;
						while (logPiOfY[indProc-1][i]>frontieresMoy[indProc-1][levelAux] && levelAux<(nbStrates-1)) 
						{
							levelAux++;
						}
						if (levelAux == level)
						{
							tabIndAux[nbIndAux]=i;
							nbIndAux ++;
						}
                    }
				
					if (nbIndAux==0)
					{
						/* updating the acceptation-rejection counter */
						nbAccRejJump[indProc][0] -= 1;
						
						/* cannot do a jump -- copying current state into new state */			
                        for (indDim=0; indDim<d; indDim++)
                        {
							Y[indProc][indDim+ d*n] = Y[indProc][indDim + d*(n-1)];
						}
					}

                    else
                    {
						/* choose a state in the auxiliary process */
						indAux = tabIndAux[(int) floor(gsl_rng_uniform(r) * nbIndAux)];
						
						/* copying the new state */
						for(indDim=0; indDim<d; indDim++) 
						{
							Y[indProc][indDim+d*n] = Y[indProc-1][indDim+d*indAux];
						}
						/* acceptation/rejection stage */
						if (log(gsl_rng_uniform(r)) > (logPiCible(Y[indProc], n, T[indProc]) - logPiCible(Y[indProc], n-1, T[indProc]) + logPiCible(Y[indProc], n-1, T[indProc-1]) - logPiCible(Y[indProc], n, T[indProc-1])))
                        {
							/* updating the acceptation-rejection counter */
							nbAccRejJump[indProc][0] -= 1;
							nbAccRejJump[indProc][1] += 1;
							/* rejection -- copying current state into new state */
							for (i=0; i<d; i++) Y[indProc][i + d*n] = Y[indProc][i + d*(n-1)];	
                        }
							
					}		
				}
				
				/* updating the results */
				logPiOfY[indProc][n] = logPiCible(Y[indProc],n,1.0);
				
				/* updating the ring bounds */
				for (i=0; i<(nbStrates-1); i++)
				{
                    aux = (double)(i+1)/nbStrates;
					frontieres[indProc][i] = frontieres[indProc][i] + constAS[indProc]*pow((n+1-indProc*initialSize),-vitesse) * (aux - ((logPiOfY[indProc][n])<= frontieres[indProc][i]));
					frontieresMoy[indProc][i] = frontieresMoy[indProc][i] -  (frontieresMoy[indProc][i] - frontieres[indProc][i])/(n-indProc*initialSize+1);
				}
			}
		}
		/* recording ring bounds */
		for (indProc=0; indProc<nbProcessus;indProc++)
		{				
			for (i=0; i<(nbStrates-1); i++)
			{
				FRONT[i+(nbStrates-1)*n+(nbStrates-1)*(Nmax+nbProcessus*initialSize)*indProc] = frontieresMoy[indProc][i];
			} 
		}
	}
	
	
     /* end of the function -- printing the acceptation rates */
     printf("\n");
    
    for (indProc=0; indProc<nbProcessus; indProc++){
		printf("SAAEES : acceptation rate of HM steps for chain number %d : %f \n", indProc, 100*(double)(nbAccRejHM[indProc][0])/(double)(nbAccRejHM[indProc][0] + nbAccRejHM[indProc][1]));
	}
    
    printf("\n");
    
    for (indProc=1; indProc<nbProcessus; indProc++){
		printf("SAAEES : acceptation rate of jumps for chain number %d : %f \n", indProc, 100*(double)(nbAccRejJump[indProc][0])/(double)(nbAccRejJump[indProc][0] + nbAccRejJump[indProc][1]));
	}
    
    printf("\n");
    
    
	
	/* recording the results */
	for (i=0; i<d; i++) for(n=nbProcessus*initialSize; n<(Nmax+nbProcessus*initialSize); n++) X[i+d*(n-nbProcessus*initialSize)]=Y[nbProcessus-1][i+d*n];
	
	/* free memory */
	for(i=0; i<nbProcessus; i++){
		free(Y[i]); free(logPiOfY[i]); 
    }
    for (i=0; i<(nbProcessus);i++){
            free(frontieres[i]);
            free(frontieresMoy[i]);
    }
    free(Y); free(logPiOfY); free(tabIndAux); free(frontieres); free(frontieresMoy);
    
    for (i=0; i<nbProcessus; i++){
		free(nbAccRejHM[i]);
	}
	
	free(nbAccRejHM);
	
	for (i=0; i<nbProcessus; i++){
		free(nbAccRejJump[i]);
	}
	
	free(nbAccRejJump);

}








void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
	/* initializing random generator */	
	struct timeval tv;
	gettimeofday(&tv,0);
	gsl_rng_default_seed = tv.tv_sec + tv.tv_usec;
    r = gsl_rng_alloc (gsl_rng_default);	
    
    /* Check for proper number of arguments */
    
    if (nrhs != 8) { 
	mexErrMsgTxt("Eight input arguments required."); 
    } else if (nlhs > 2) {
	mexErrMsgTxt("Too many output arguments."); 
    } 

	/* Read arguments into proper C variable */
    paramCible = mxGetPr(paramCible_IN);
    nbProcessus = mxGetM(T_IN);
    T = mxGetPr(T_IN);
	nbStrates = mxGetM(frontieres_IN)+1;
	frontieresNonAdapt = mxGetPr(frontieres_IN);
    Nmax = (int) (*mxGetPr(Nmax_IN));
    sqrtGamma = mxGetPr(sqrtGamma_IN);
    d = mxGetM(sqrtGamma_IN);
    epsilon = (double) (*mxGetPr(epsilon_IN));    
    constAS = mxGetPr(constAS_IN);
    nbInit = mxGetPr(nbInit_IN);
    
   burnInSize = (int) nbInit[0];
	initialSize = (int) (nbInit[1]+burnInSize);
    /* Create a matrix for the return argument */ 
    X_OUT = mxCreateDoubleMatrix(d, Nmax, mxREAL); 
     FRONT_OUT = mxCreateDoubleMatrix(nbStrates-1,(Nmax+nbProcessus*initialSize)*nbProcessus, mxREAL);  
    X = mxGetPr(X_OUT);
     FRONT = mxGetPr(FRONT_OUT); 
    
    /* call main function, and return */
    
    printf("nbProcessus = %d, nbStrates = %d : calling main function...\n", nbProcessus, nbStrates);
    
    equiSampler();
    
    gsl_rng_free(r);
    return;    
}
