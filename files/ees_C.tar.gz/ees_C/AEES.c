/*=================================================================
 *
 * Adaptive Equi-Energy Sampler for a mixture of Gaussians
 * 
 * 
 * See sampling.m for an example of use
 * 
 * Command to run before using the function in matlab/octave:
 * mex -v -lgsl -lgslcblas AEES.c 
 *
 *=================================================================*/
 
/* libraries */
#include <math.h>
#include <gsl/gsl_rng.h>
#include "mex.h"
#include <sys/time.h>


/* random number generator */
gsl_rng * r; 

/* global variables */
int initialSize, burnInSize;
int d, Nmax, nbProcessus, nbStrates;
double *paramCible, *X, *T, *sqrtGamma, *FRONT, *constAS, *nbInit;
double epsilon;


/* Input Arguments -- see sampling.m for details */
#define	paramCible_IN prhs[0]
#define	T_IN prhs[1]
#define Nmax_IN prhs[2]
#define sqrtGamma_IN prhs[3]
#define epsilon_IN prhs[4]
#define constAS_IN prhs[5]
#define nbInit_IN prhs[6]
#define nbStrates_IN prhs[7]


/* Output Arguments -- see sampling.m for details */

#define	X_OUT plhs[0]
#define	FRONT_OUT plhs[1] 



/* miscellaneous definitions, in case of */
#if !defined(PI)
#define PI 3.14159265358979323846
#endif

#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif




	
/* Gaussian sampler */
double
gsl_ran_gaussian (const gsl_rng * r)
{
  double x, y, r2;

  do
    {
      /* choose x,y in uniform square (-1,-1) to (+1,+1) */

      x = -1 + 2 * gsl_rng_uniform (r);
      y = -1 + 2 * gsl_rng_uniform (r);

      /* see if it is in the unit circle */
      r2 = x * x + y * y;
    }
  while (r2 > 1.0 || r2 == 0);

  /* Box-Muller transform */
  return y * sqrt (-2.0 * log (r2) / r2);
}



/* log value of the target distribution at the temperature t */
double logPiCible(double* Y, int n, double t){
	/* variables declaration */
	int i, j;
	double res = 0, tmp;
	/* parameters of the target distribution */
	int nbGaussian = (int)(paramCible[0]);
	double* poids = &(paramCible[1]);
	double* mu = &(paramCible[1+nbGaussian]);
	double* sig2 = &(paramCible[1+nbGaussian+nbGaussian*d]);
	
	/* computation of pi */
	for (i=0; i<nbGaussian; i++){
		tmp = 0;
		for(j=0; j<d; j++){
			tmp += (Y[j+n*d]-mu[j+i*d])*(Y[j+n*d]-mu[j+i*d]);
		}
		res += poids[i]/(pow(2*PI*sig2[i],(double)d/2)) * exp(-0.5*tmp/sig2[i]);
	}
	return log(res)/t;
}



/* symmetric random walk Metropolis-Hasting */
void srwm(double* Y, int n, double t, int** nbAccRejHM, int indProcessus){
	int i,j;
	double* z;
	z = malloc(d * sizeof(double));
	for (i=0; i<d; i++) z[i] = gsl_ran_gaussian(r);
	for (i=0; i<d; i++)
	{
		Y[i+ d*n] = Y[i + d*(n-1)]; 
		for (j=0; j<d; j++) 
			Y[i + d*n] += sqrt(t)*sqrtGamma[i + d*j]*z[j]; 
	}
	free(z);
	nbAccRejHM[indProcessus][0] += 1;
	if (log(gsl_rng_uniform(r)) > logPiCible(Y, n, t) - logPiCible(Y, n-1, t)){
		for (i=0; i<d; i++) Y[i + d*n] = Y[i + d*(n-1)];	
		nbAccRejHM[indProcessus][0] -= 1;
		nbAccRejHM[indProcessus][1] += 1;
	}
}

/* auxiliary function for quick sort */
int partition(double *tableauAux, int *ordre, int debut, int fin){
	double pivot = tableauAux[debut];
	int i=debut-1;
	int j=fin+1;
	double temp;
	int tempOrdre;
	while (i<j){
	    do {
            j--;
	    }
		while (tableauAux[j]>pivot);
        do {
            i++;
        }
		while (tableauAux[i]<pivot);
		if (i<j){
            temp=tableauAux[i];
            tableauAux[i] = tableauAux[j];
            tableauAux[j] = temp;
            tempOrdre=ordre[i];
            ordre[i]=ordre[j];
            ordre[j]=tempOrdre;
		}
	}
	return j;
}


/* quick sort */
void triRapide(double *tableauAux, int *ordre, int debut, int fin) {
    int milieu, i;

    /* sorting */
    if (debut < fin) {
        milieu = partition(tableauAux, ordre, debut, fin);
        triRapide(tableauAux, ordre, debut, milieu);
        triRapide(tableauAux, ordre, milieu+1, fin);
    }
}



/* main function */
void equiSampler(){
	

	/* -------------- variables declaration --------- */
	
	int indProc, n, indDim, i, j, level, strate, indAux;
    double aux;
	double** Y;
    double** logPiOfY;
    double* logPiOfYaux;
    int* ordre;
	
    int** nbAccRejHM;
    nbAccRejHM = malloc(nbProcessus * sizeof(int*));
    for (i=0; i<nbProcessus; i++){
		nbAccRejHM[i] = malloc(2 * sizeof(int));
		nbAccRejHM[i][0]=0;
		nbAccRejHM[i][1]=0;
	}
	
	int** nbAccRejJump;
    nbAccRejJump = malloc(nbProcessus * sizeof(int*));
    for (i=0; i<nbProcessus; i++){
		nbAccRejJump[i] = malloc(2 * sizeof(int));
		nbAccRejJump[i][0]=0;
		nbAccRejJump[i][1]=0;
	}
	
    
	Y = malloc(nbProcessus * sizeof(double*));
	logPiOfY = malloc(nbProcessus * sizeof(double*));
	ordre = malloc((Nmax + nbProcessus*initialSize) * sizeof(int));
	
	for (indProc=0; indProc<nbProcessus; indProc++){
		Y[indProc] = malloc(d * (Nmax + nbProcessus*initialSize) * sizeof(double));
		logPiOfY[indProc] = malloc( (Nmax + nbProcessus*initialSize)  * sizeof(double));
		logPiOfYaux = malloc( (Nmax + nbProcessus*initialSize)  * sizeof(double));
	}
	
    int nbPointsParRing;
    
    double** frontieres;
    int* tabIndAux;
    int nbIndAux=0, levelAux;
    
    tabIndAux = malloc((Nmax + nbProcessus*initialSize) * sizeof(int));
    frontieres = malloc(nbProcessus * sizeof(double*));
    
    for (i=0; i<(nbProcessus);i++){
		frontieres[i] = malloc((nbStrates - 1) * sizeof(double));
    }

	
	/* --------- initialization ---------------- */
	
	
	for (indProc=0; indProc< nbProcessus; indProc++){

		/* random initialization of the chains */
		for (indDim=0; indDim < d; indDim++){
			Y[indProc][indDim + (indProc*initialSize)*d] = -2.1; /* +gsl_rng_uniform(r); */
		}
		/* value of pi for the random states */
		logPiOfY[indProc][indProc*initialSize] = logPiCible(Y[indProc],indProc*initialSize,1.0);
	}
	
	
            
	/* ----------- run ------------------------- */
	

		
	for (n=1; n<(Nmax + nbProcessus*initialSize); n++){

		/* --- very hot process --- */
		
		/* sample of the new state */
		srwm(Y[0], n, T[0], nbAccRejHM, 0);
		/* energy */
		logPiOfY[0][n] = logPiCible(Y[0],n,1.0);

		
		/* --- other processes --- */
		for (indProc=1; indProc< nbProcessus; indProc++){
			if (n>indProc*initialSize) /* burn-in */
			{ 
				/* sampling the new state */
				if (gsl_rng_uniform(r)>epsilon)
				{
					srwm(Y[indProc], n, T[indProc],nbAccRejHM, indProc);
				}
                else{
					/* updating the acceptation-rejection counter */
					nbAccRejJump[indProc][0] += 1;
					
					/* number of states per ring */
					nbPointsParRing = (int) (floor((n-((indProc-1)*initialSize+burnInSize)+1)/nbStrates));
					
					if (nbPointsParRing==0)
					{
						/* updating the acceptation-rejection counter */
						nbAccRejJump[indProc][0] -= 1; /* doesn't count as a jump ! */
						
						/* cannot do a jump -- copying current state into new state */
                        for (indDim=0; indDim<d; indDim++)
                        {
							Y[indProc][indDim+ d*n] = Y[indProc][indDim + d*(n-1)];
						}
					}
					else 
					{
						
						/* initialization of auxiliary variables */
						for (i= (indProc-1)*initialSize+burnInSize; i<(n+1); i++){
							ordre[i]=i;
							logPiOfYaux[i]=logPiOfY[indProc-1][i];
						}
						
						triRapide(logPiOfYaux, ordre, (indProc-1)*initialSize+burnInSize, n);

						for (i=0;i<(nbStrates-1);i++){
							frontieres[indProc-1][i]=(logPiOfYaux[(indProc-1)*initialSize+burnInSize+(i+1)*nbPointsParRing]+logPiOfYaux[(indProc-1)*initialSize+burnInSize+(i+1)*nbPointsParRing-1])/2;
						}

						/* level of the current state */
						level=0;
						while (logPiOfY[indProc][n-1]>frontieres[indProc-1][level] && level<(nbStrates-1)) 
						{
							level++;
						}	
								
						indAux = ordre[(int) ((indProc-1)*initialSize+burnInSize+nbPointsParRing*level+ floor(gsl_rng_uniform(r) * nbPointsParRing))];
						

						/* copying the new state */
						for(indDim=0; indDim<d; indDim++) 
						{
							Y[indProc][indDim+d*n] = Y[indProc-1][indDim+d*indAux];
						}
						
						/* acceptation/rejection stage */
						if (log(gsl_rng_uniform(r)) > (logPiCible(Y[indProc], n, T[indProc]) - logPiCible(Y[indProc], n-1, T[indProc]) + logPiCible(Y[indProc], n-1, T[indProc-1]) - logPiCible(Y[indProc], n, T[indProc-1])))
                        {
							/* updating the acceptation-rejection counter */
							nbAccRejJump[indProc][0] -= 1;
							nbAccRejJump[indProc][1] += 1;
							/* rejection -- copying current state into new state */
							for (i=0; i<d; i++) Y[indProc][i + d*n] = Y[indProc][i + d*(n-1)];	
                        }
                        
							
					}		
				}
				
				/* updating the results */
				logPiOfY[indProc][n] = logPiCible(Y[indProc],n,1.0);
				
			}
		}
		/* recording ring bounds */
		for (indProc=0; indProc<nbProcessus;indProc++)
		{				
			for (i=0; i<(nbStrates-1); i++)
			{
				FRONT[i+(nbStrates-1)*n+(nbStrates-1)*(Nmax+nbProcessus*initialSize)*indProc] = frontieres[indProc][i];
			} 
		}

	}
	
	
	
     /* end of the function -- printing the acceptation rates */
     printf("\n");
    
    for (indProc=0; indProc<nbProcessus; indProc++){
		printf("AEES : acceptation rate of HM steps for chain number %d : %f \n", indProc, 100*(double)(nbAccRejHM[indProc][0])/(double)(nbAccRejHM[indProc][0] + nbAccRejHM[indProc][1]));
	}
    
    printf("\n");
    
    for (indProc=1; indProc<nbProcessus; indProc++){
		printf("AEES : acceptation rate of jumps for chain number %d : %f \n", indProc, 100*(double)(nbAccRejJump[indProc][0])/(double)(nbAccRejJump[indProc][0] + nbAccRejJump[indProc][1]));
	}
    
    printf("\n");
    
	
	/* recording the results */
	for (i=0; i<d; i++) for(n=nbProcessus*initialSize; n<(Nmax+nbProcessus*initialSize); n++) X[i+d*(n-nbProcessus*initialSize)]=Y[nbProcessus-1][i+d*n];
	
	/* free memory */
	
	
	for(i=0; i<nbProcessus; i++){
		free(Y[i]); free(logPiOfY[i]);
    }
    for (i=0; i<(nbProcessus);i++){
            free(frontieres[i]);
    }
    free(Y); free(logPiOfY); free(logPiOfYaux); free(tabIndAux); free(frontieres);
    free(ordre);
    
    for (i=0; i<nbProcessus; i++){
		free(nbAccRejHM[i]);
	}
	
	free(nbAccRejHM);
	
	for (i=0; i<nbProcessus; i++){
		free(nbAccRejJump[i]);
	}
	
	free(nbAccRejJump);

}








void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
	/* initializing random generator */	
	struct timeval tv;
	gettimeofday(&tv,0);
	gsl_rng_default_seed = tv.tv_sec + tv.tv_usec;
    r = gsl_rng_alloc (gsl_rng_default);	
    
    /* Check for proper number of arguments */
    
    if (nrhs != 8) { 
	mexErrMsgTxt("Eight input arguments required."); 
    } else if (nlhs > 2) {
	mexErrMsgTxt("Too many output arguments."); 
    } 

	/* Read arguments into proper C variable */
    paramCible = mxGetPr(paramCible_IN);
    nbProcessus = mxGetM(T_IN);
    T = mxGetPr(T_IN);
	nbStrates = (int) (*mxGetPr(nbStrates_IN));
    Nmax = (int) (*mxGetPr(Nmax_IN));
    sqrtGamma = mxGetPr(sqrtGamma_IN);
    d = mxGetM(sqrtGamma_IN);
    epsilon = (double) (*mxGetPr(epsilon_IN));    
    constAS = mxGetPr(constAS_IN);
    nbInit = mxGetPr(nbInit_IN);
   	
	burnInSize = (int) nbInit[0];
	initialSize = (int) (nbInit[1]+burnInSize);
    /* Create a matrix for the return argument */ 
    X_OUT = mxCreateDoubleMatrix(d, Nmax, mxREAL); 
     FRONT_OUT = mxCreateDoubleMatrix(nbStrates-1,(Nmax+nbProcessus*initialSize)*nbProcessus, mxREAL);  
    X = mxGetPr(X_OUT);
     FRONT = mxGetPr(FRONT_OUT); 
    
    /* call main function, and return */
    
    printf("nbProcessus = %d, nbStrates = %d : calling main function...\n", nbProcessus, nbStrates);
    
    equiSampler();
    
    gsl_rng_free(r);
    return;    
}
