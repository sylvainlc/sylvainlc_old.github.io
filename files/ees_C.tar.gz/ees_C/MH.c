/*=================================================================
 *
 * Metropolis-Hastings Sampler for a mixture of Gaussians
 * 
 * 
 * See sampling.m for an example of use
 * 
 * Command to run before using the function in matlab/octave:
 * mex -v -lgsl -lgslcblas MH.c 
 *
 *=================================================================*/
 
 
 
/* libraries */
#include <math.h>
#include <gsl/gsl_rng.h>
#include "mex.h"
#include <sys/time.h>

/* random number generator */
gsl_rng * r; 

/* global variables */
int d, Nmax, nbProcessus, nbStrates;
double *paramCible, *frontieresNonAdapt, *X, *T, *sqrtGamma;
double epsilon;

/* Input Arguments -- see sampling.m for details */
#define	paramCible_IN prhs[0]
#define	T_IN prhs[1]
#define frontieres_IN prhs[2]
#define Nmax_IN prhs[3]
#define sqrtGamma_IN prhs[4]
#define epsilon_IN prhs[5]

/* Output Arguments -- see sampling.m for details */
#define	X_OUT plhs[0]


/* miscellaneous definitions, in case of */
#if !defined(PI)
#define PI 3.14159265358979323846
#endif

#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif



/* Gaussian sampler */
double
gsl_ran_gaussian (const gsl_rng * r)
{
  double x, y, r2;

  do
    {
      /* choose x,y in uniform square (-1,-1) to (+1,+1) */

      x = -1 + 2 * gsl_rng_uniform (r);
      y = -1 + 2 * gsl_rng_uniform (r);

      /* see if it is in the unit circle */
      r2 = x * x + y * y;
    }
  while (r2 > 1.0 || r2 == 0);

  /* Box-Muller transform */
  return y * sqrt (-2.0 * log (r2) / r2);
}



/* log value of the target distribution at the temperature t */
double logPiCible(double* Y, int n, double t){
	/* variables declaration */
	int i, j;
	double res = 0, tmp;
	/* parameters of the target distribution */
	int nbGaussian = (int)(paramCible[0]);
	double* poids = &(paramCible[1]);
	double* mu = &(paramCible[1+nbGaussian]);
	double* sig2 = &(paramCible[1+nbGaussian+nbGaussian*d]);
	
	/* computation of pi */
	for (i=0; i<nbGaussian; i++){
		tmp = 0;
		for(j=0; j<d; j++){
			tmp += (Y[j+n*d]-mu[j+i*d])*(Y[j+n*d]-mu[j+i*d]);
		}
		res += poids[i]/(pow(2*PI*sig2[i],(double)d/2)) * exp(-0.5*tmp/sig2[i]);
	}
	return log(res)/t;
}



/* symmetric random walk Metropolis-Hasting */
void srwm(double* Y, int n, double t){
	int i,j;
	double* z;
	z = malloc(d * sizeof(double));
	for (i=0; i<d; i++) z[i] = gsl_ran_gaussian(r);
	for (i=0; i<d; i++){
		Y[i+ d*n] = Y[i + d*(n-1)]; 
		for (j=0; j<d; j++) 
			Y[i + d*n] += sqrt(t)*sqrtGamma[i + d*j]*z[j]; 
	}
	free(z);
	if (log(gsl_rng_uniform(r)) > logPiCible(Y, n, t) - logPiCible(Y, n-1, t))
		for (i=0; i<d; i++) Y[i + d*n] = Y[i + d*(n-1)];	
}



/* main function */
void equiSampler(){
	
    
    
	/* -------------- variables declaration --------- */
	
	int  burnInSize=200;
	int n, indDim, i, j;
	double* Y;    

	Y = malloc(d * (Nmax + burnInSize) * sizeof(double));
	
	
	/* --------- initialization ---------------- */
	
	
	for (indDim=0; indDim < d; indDim++){
		Y[indDim + 0*d] = -2.1;
	}
	 
	/* ----------- run ------------------------- */
	
	for (n=1; n<(Nmax + burnInSize); n++){
		srwm(Y, n, 1);
	}
	

	/* recording the results */
	for (i=0; i<d; i++) for(n=burnInSize; n<(Nmax+burnInSize); n++) X[i+d*(n-burnInSize)]=Y[i+d*n];
	
	/* free memory */

    free(Y);
}








void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
	/* initializing random generator */	
	struct timeval tv;
	gettimeofday(&tv,0);
	gsl_rng_default_seed = tv.tv_sec + tv.tv_usec;
    r = gsl_rng_alloc (gsl_rng_default);	
    
    /* Check for proper number of arguments */
    
    if (nrhs != 6) { 
	mexErrMsgTxt("Six input arguments required."); 
    } else if (nlhs > 1) {
	mexErrMsgTxt("Too many output arguments."); 
    } 

	/* Read arguments into proper C variable */
    paramCible = mxGetPr(paramCible_IN);
    nbProcessus = mxGetM(T_IN);
    T = mxGetPr(T_IN);
	nbStrates = mxGetM(frontieres_IN)+1;
	frontieresNonAdapt = mxGetPr(frontieres_IN);
    Nmax = (int) (*mxGetPr(Nmax_IN));
    sqrtGamma = mxGetPr(sqrtGamma_IN);
    d = mxGetM(sqrtGamma_IN);
    epsilon = (double) (*mxGetPr(epsilon_IN));    
   
    /* Create a matrix for the return argument */ 
    X_OUT = mxCreateDoubleMatrix(d, Nmax, mxREAL); 
    X = mxGetPr(X_OUT);
    
    /* call main function, and return */
    
    printf("nbProcessus = %d, nbStrates = %d : calling main function...\n", nbProcessus, nbStrates);
    
    equiSampler();
    
    gsl_rng_free(r);
    return;    
}
