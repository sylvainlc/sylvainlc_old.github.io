clear all


% mex commands to run before using fonction.c in matlab or octave

%mex -v -lgsl -lgslcblas MH.c
%mex -v -lgsl -lgslcblas EES.c
%mex -v -lgsl -lgslcblas AEES.c
%mex -v -lgsl -lgslcblas SAAEES.c



% warning : for matlab with 64-bits linux, the command may be :
%
% mex -v -lgsl -lgslcblas function.c -L/location_of_the_file "-lstdc++"




% ---------- parameters of the target distribution ---------- %


% number of Gaussians
nb_gauss = 2;
% dimension
d=6;
% means of the Gaussians
mu=[-2+zeros(d,1) 2+zeros(d,1)];
% variances of the Gaussians
sig2 = [0.3 0.3];
% weights of the Gaussians
w = 1/nb_gauss * ones(1, nb_gauss);

% concatenation of previous parameters
paramCible = [nb_gauss, w, mu(:)', sig2];



% ---------- parameters of the algorithms ---------- %


% ring bounds -- used by SAAEES for the initialization  of the bounds
frontieres = log((0.1:0.005:0.18)');
% temperatures of the chains
T=[30;1];
% constants for the adaptation with stochastic approximation
cste_AS=T/2;
% probability of making an equi-energy move
epsilon = 0.05;

% covariance matrix for the proposal (and its choleski decomposition)
Gamma = 0.35*eye(d);
sqrtGamma = chol(Gamma);


% ---------- number of iterations ---------- %

% number of states in the chain of interest
Nmax = 20000;
% burn-in
B=1000;
% minimum size of a useful ring
N=1000;

% corresponding parameter
nb_init = [B;N];



% ---------- sampling ---------- %


[X_AEES,bornes_aees] = AEES(paramCible, T, Nmax, sqrtGamma, epsilon,cste_AS,nb_init,length(frontieres)+1);

[X_SAAEES,bornes_saaees] = SAAEES(paramCible, T, frontieres, Nmax, sqrtGamma, epsilon,cste_AS,nb_init);

X_EES = EES(paramCible, T, frontieres, Nmax, sqrtGamma, epsilon);

X_HM = MH(paramCible, T, frontieres, Nmax, sqrtGamma, epsilon);
	


% keeping the updates of the ring bounds for AEES and SAAEES in an easier-to-read array
% the dimension are : (index of the level, iteration, index of the process)

front_aees = zeros(length(frontieres),Nmax,length(T));
front_saaees = zeros(length(frontieres),Nmax,length(T));

for i=1:length(T)
	front_aees(:,:,i) = bornes_aees(:,(1+(i-1)*Nmax):i*Nmax);
	front_saaees(:,:,i) = bornes_saaees(:,(1+(i-1)*Nmax):i*Nmax);
end



