/*=================================================================
 *
 * mex-matlab code for STMALA - revision 18/12/2013
 * 
 * general command to compile :
 * mex -v -lgsl -lgslcblas -lblas stmala.c 
 *
 * command on linux 64 bits @tsi to compile :
 *  mex -v -lgsl -lgslcblas -lblas stmala.c -L/usr/lib/gcc/x86_64-linux-gnu/4.3/
 * 
 * command with octave
 * mex -v -lgsl -lgslcblas -lblas stmala.c
 * 
 *=================================================================*/


/* ------------------------- definitions ----------------------------*/


/* libraries */
#include <math.h>
#include <gsl/gsl_rng.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "mex.h"
/* utile si dgemm :
#include "matrix.h" */
#include "cblas.h"


/* random number generator */
gsl_rng * r; 
    
/* definition of the global variables */
int nb_it, B, P, T, N, st_fun, size_block;
double tau, c_pen, c_pen_elast, sigma, thresh, trunc_grad, c_lambda, par_prior_w, pas_grad;
double *acceptation, *mean_X, *mean_mod, *Y, *G, *init, *GtY, *GtG;
/* utile si dgemm :
char trans,notrans;
double alpha,beta; */
double  *GtGx, *GtGz ;
int *indices_bloc;
double *mu_x, *mu_z, *Z;
double *Gx;

/* Input Arguments */
#define	B_IN              prhs[0]   /* burn-in size */
#define	nb_it_IN          prhs[1]   /* number of iterations */
#define	N_IN              prhs[2]   /* number of observations */
#define	P_IN              prhs[3]   /* number of regressors */
#define	T_IN              prhs[4]   /* number of time step */
#define	Y_IN              prhs[5]   /* obervations vector */
#define	G_IN              prhs[6]   /* design matrix */
#define	tau_IN            prhs[7]   /* observation noise */
#define	c_pen_IN          prhs[8]   /* penality constant in the target distribution */
#define	c_pen_elast_IN    prhs[9]   /* elastic penality constant in the target distribution */
#define	c_lambda_IN       prhs[10]  /* renormalisation constant */
#define	par_prior_w_IN    prhs[11]  /* parameter of the Bernouilli prior on the models */
#define	st_fun_IN         prhs[12]  /* choice of the shrinkage-thresholding operator */
#define	init_IN           prhs[13]  /* initial point */
#define	sigma_IN          prhs[14]  /* standard deviation of the proposal distribution */
#define	thresh_IN         prhs[15]  /* threshold gamma */
#define	trunc_grad_IN     prhs[16]  /* level of truncation for the gradient */
#define	size_block_IN     prhs[17]  /* size of the block to be updated */


/* Output Arguments */
#define	mean_X_OUT            plhs[0]  /* mean estimated regressor */
#define	mean_mod_OUT          plhs[1]  /* mean estimated model */
#define	acceptation_OUT       plhs[2]  /* binary vector of acceptance */

        
#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif

#define pi 3.1415926535897932384626433832795028841971693992


/* --------------------- auxiliary functions -------------------------*/



/* auxiliary function 1 : sample a Gaussian random variable */
double gsl_ran_gaussian (const gsl_rng * r)
{
  double x, y, r2;

  do
    {
      /* choose x,y in uniform square (-1,-1) to (+1,+1) */

      x = -1 + 2 * gsl_rng_uniform (r);
      y = -1 + 2 * gsl_rng_uniform (r);

      /* see if it is in the unit circle */
      r2 = x * x + y * y;
    }
  while (r2 > 1.0 || r2 == 0);

  /* Box-Muller transform */
  return y * sqrt (-2.0 * log (r2) / r2);
}


/* auxiliary function 2 : compute the (n,k) binomial coefficient */
double logbin(int n, int k)
{
    double sum = 0;
    int i;
    for(i=0;i<k;i++)
    {
        sum = sum + log(n-i) - log(i+1);
    }
    return sum;
}

/* auxiliary function 3 : compute normal cumulative distribution in x with mean 0 and sd 1 */
double normcdf(double x)
{
    double y;
    double c1;
    double c2;
    double c3;
    double z,z2,z3;
    c1 = 0.4361836;
    c2 = -0.1201676;
    c3 = 0.9772980;
   
    if (x>0)
    {
        z  = 1 + 0.33267*x;
        z2 = (1 + 0.33267*x)*(1 + 0.33267*x);
        z3 = z2*(1 + 0.33267*x);
        y = 1 - exp(-x*x/2)*(c1/z + c2/z2 + c3/z3)/sqrt(2*pi);
    }
    else
    {
        z  = 1 - 0.33267*x;
        z2 = (1 - 0.33267*x)*(1 - 0.33267*x);
        z3 = z2*(1 - 0.33267*x);
        y = exp(-x*x/2)*(c1/z + c2/z2 + c3/z3)/sqrt(2*pi);
    }
    return y;
}


/* auxiliary function 4 : computation of log pi */
double log_pi(double *X, int size_mX)
{
	/* definition and allocation */
	double log_pi_X=0.;
	double norm2_Xi;
	int i,j;
	
	/* computation of Gx */
	cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,N,T,P,1.0,G,P,X,T,0.0,Gx,T);
	/* dgemm(&notrans,&notrans,&N,&T,&P,&alpha,G,&N,X,&P,&beta,Gx,&N); */
	
	/* computation of the Gaussian part of log pi */
	for(i=0;i<N;i++)
    {
        for(j=0;j<T;j++)
        {
            log_pi_X = log_pi_X - (Y[i*T+j] - Gx[i*T+j]) * (Y[i*T+j] - Gx[i*T+j]);
        }    
    }
    log_pi_X = log_pi_X * 0.5 / tau;
    
   
    /* computation of the penalized part of log pi */
    for(i=0;i<P;i++)
    {
		norm2_Xi = 0.;
		for(j=0;j<T;j++)
		{
			norm2_Xi = norm2_Xi + X[T*i+j] * X[T*i+j];
		}
		log_pi_X = log_pi_X - c_pen * sqrt(norm2_Xi) - c_pen_elast * norm2_Xi;
	}
	
	/* computation of the weight of the model of X in log pi */
	log_pi_X = log_pi_X - size_mX * log(c_lambda) + size_mX * log(par_prior_w) + (P-size_mX) * log(1-par_prior_w);
	
	/* result */
	return log_pi_X;
}


/* ----------------------- move functions ---------------------------*/


/* 1 : move associated with the soft thresholding with vanishiing shrinkage operator */

void stmala_move(int n, double* X, double* log_pi_X, int* size_mX)
{
	
	/* definition and allocation */
	int i,j;
	
	int size_block_temp = 0;
	int new_index_block, test_index, size_mZ, act_row;
	
	double c_trunc_grad_x, c_trunc_grad_z, norm2_Zi, norm2_Xi, shrink, acc, log_pi_Z, alpha;
	double log_q_xz, log_q_zx, par_cen, par_h, par_p, par_m, mass_0, norm2_gzc, g_u;
		
	/* auxiliary computations */
	cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,P,T,P,1.0,GtG,P,X,T,0.0,GtGx,T);
	/* dgemm(&notrans,&notrans,&P,&T,&P,&alpha,GtG,&P,X,&P,&beta,GtGx,&P); */
	
	/* selection of the indices of the components to be updated */
	
	if(size_block < P)
	{
		new_index_block = floor(gsl_rng_uniform(r) * P);
		indices_bloc[size_block_temp] = new_index_block;
		size_block_temp += 1;
		
		while(size_block_temp<size_block)
		{
			/* sample a new index */
			new_index_block = floor(gsl_rng_uniform(r) * P);
			
			/* test if the new index was already selected */
			test_index = 0;
			for(i=0;i<size_block_temp;i++)
			{
				if(new_index_block == indices_bloc[i])
				{
					test_index = 1;
				}
			}
			
			/* add the new index if not already selected */
			if(test_index==0)
			{
				indices_bloc[size_block_temp] = new_index_block;
				size_block_temp += 1;
			}
		}
	}
	else
	{
		for(i=0;i<P;i++)
		{
			indices_bloc[i] = i;
		}
	}

	
	/* computation of the truncation constant for the gradient */
	c_trunc_grad_x = 0;
	for(i=0;i<P;i++)
	{
		for(j=0;j<T;j++)
		{
			c_trunc_grad_x = c_trunc_grad_x + (GtY[i*T+j] - GtGx[i*T+j]) * (GtY[i*T+j] - GtGx[i*T+j]);
		}
	}
	
	c_trunc_grad_x = sqrt(c_trunc_grad_x)/tau;
	c_trunc_grad_x = MAX(c_trunc_grad_x,trunc_grad);
	c_trunc_grad_x = trunc_grad/c_trunc_grad_x;
	
	
	/* computation of the proposed point before noise + shrinkage */
	for(i=0;i<P;i++)
	{
		for(j=0;j<T;j++)
		{
			mu_x[i*T+j] = X[i*T+j];
			Z[i*T+j] = X[i*T+j];
		}
	}
	
	for(i=0;i<size_block;i++)
	{
		for(j=0;j<T;j++)
		{
			mu_x[indices_bloc[i]*T+j] = mu_x[indices_bloc[i]*T+j] + pas_grad/tau*c_trunc_grad_x * (GtY[indices_bloc[i]*T+j]-GtGx[indices_bloc[i]*T+j]);			
		}
	}
	
	/* noise + shrinkage of the proposed point */

	for(i=0;i<size_block;i++)
	{
		/* add noise */
		norm2_Zi = 0.;
		for(j=0;j<T;j++)
		{			
			Z[indices_bloc[i]*T+j] = mu_x[indices_bloc[i]*T+j] + sigma * gsl_ran_gaussian(r);
			norm2_Zi = norm2_Zi + Z[indices_bloc[i]*T+j]*Z[indices_bloc[i]*T+j];
		}
		
		/* computation of the shrinkage constant */
		shrink = 1. - thresh*thresh/norm2_Zi;
		
		
		if(shrink<=0 || norm2_Zi==0)
		{
			shrink = 0.;
		}		
		
		/* shrinkage */
		for(j=0;j<T;j++)
		{
			Z[indices_bloc[i]*T+j] = Z[indices_bloc[i]*T+j] * shrink;
		}		
	}	
	
	/* computations of Gt*G*z */
	cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,P,T,P,1.0,GtG,P,Z,T,0.0,GtGz,T);
	/* dgemm(&notrans,&notrans,&P,&T,&P,&alpha,GtG,&P,Z,&P,&beta,GtGz,&P); */
	
	/* computation of the truncation constant for the gradient in z */
	c_trunc_grad_z = 0;
	for(i=0;i<P;i++)
	{
		for(j=0;j<T;j++)
		{
			c_trunc_grad_z = c_trunc_grad_z + (GtY[i*T+j] - GtGz[i*T+j]) * (GtY[i*T+j] - GtGz[i*T+j]);
		}
	}
	
	c_trunc_grad_z = sqrt(c_trunc_grad_z)/tau;
	c_trunc_grad_z = MAX(c_trunc_grad_z,trunc_grad);
	c_trunc_grad_z = trunc_grad/c_trunc_grad_z;
	
	/* computation of mu(z) for the updated row indices */
	
	for(i=0;i<size_block;i++)
	{
		for(j=0;j<T;j++)
		{
			mu_z[indices_bloc[i]*T+j] = Z[indices_bloc[i]*T+j] + pas_grad/tau*c_trunc_grad_z * (GtY[indices_bloc[i]*T+j]-GtGz[indices_bloc[i]*T+j]);
		}
	}
	
	/* computation of log(q(x,z))  and log(q(z,x)) */
	
	log_q_xz = 0.;
	log_q_zx = 0.;
	size_mZ = size_mX[0];
		
	for(i=0;i<size_block;i++)
	{
		/* computation of log(q(x,z)) */
		act_row = 1;
		norm2_Zi = 0;
		for(j=0;j<T;j++)
		{
			act_row = act_row * (int)(Z[indices_bloc[i]*T+j] == 0);
			norm2_Zi = norm2_Zi + Z[indices_bloc[i]*T+j]*Z[indices_bloc[i]*T+j];
		}
		act_row = 1-act_row;
		size_mZ = size_mZ + (int)(act_row);
		
		if(act_row)
		{
			g_u = (1+2.*thresh*thresh / norm2_Zi/(1+sqrt(1+4.*thresh*thresh/norm2_Zi)));
			norm2_gzc = 0.;
			for(j=0;j<T;j++)
			{			
				norm2_gzc = norm2_gzc +  (g_u * Z[indices_bloc[i]*T+j] - mu_x[indices_bloc[i]*T+j]) * (g_u * Z[indices_bloc[i]*T+j] - mu_x[indices_bloc[i]*T+j]);
			}
			log_q_xz = log_q_xz + T*log(g_u/sqrt(2*pi*sigma*sigma)) -log(1+4.*thresh*thresh/norm2_Zi)/2.0-1./(2.*sigma*sigma)*norm2_gzc;
		}
		else
		{
			par_cen = 0;
			for(j=0;j<T;j++)
			{
				par_cen = mu_x[indices_bloc[i]*T+j]*mu_x[indices_bloc[i]*T+j];
			}
			par_cen = par_cen/(sigma*sigma);
			par_h = 1. - 2./3.*(T+par_cen)*(T+3.*par_cen) / ((T+2*par_cen)*(T+2*par_cen));
			par_p = (T+2*par_cen) / ((T+par_cen)*(T+par_cen));
			par_m = (par_h -1)*(1-3*par_h);
			
			mass_0 = normcdf( ( pow(thresh*thresh/(sigma*sigma) / (T+par_cen),par_h) - 1 - par_h*par_p*(par_h - 1 - par_m*par_p*(1-0.5*par_h)) ) / (par_h*sqrt(2*par_p*(1+par_m*par_p))  ) );
	
			log_q_xz = log_q_xz + log(mass_0);
		}
		
		
		/* computation of log(q(z,x)) */
		act_row = 1;
		norm2_Xi = 0;
		for(j=0;j<T;j++)
		{
			act_row = act_row * (int)(X[indices_bloc[i]*T+j] == 0);
			norm2_Xi = norm2_Xi + X[indices_bloc[i]*T+j]*X[indices_bloc[i]*T+j];
		}
		act_row = 1-act_row;
		size_mZ = size_mZ - (int)(act_row);
		
		if(act_row)
		{
			g_u = (1+2.*thresh*thresh / norm2_Xi/(1+sqrt(1+4.*thresh*thresh/norm2_Xi)));
			norm2_gzc = 0.;
			for(j=0;j<T;j++)
			{				
				norm2_gzc = norm2_gzc +  (g_u * X[indices_bloc[i]*T+j] - mu_z[indices_bloc[i]*T+j]) * (g_u * X[indices_bloc[i]*T+j] - mu_z[indices_bloc[i]*T+j]);
			}
			log_q_zx = log_q_zx + T*log(g_u/sqrt(2*pi*sigma*sigma)) - log(1+4.*thresh*thresh/norm2_Xi)/2.0 -1./(2.*sigma*sigma)*norm2_gzc;
		}
		else
		{
			par_cen = 0;
			for(j=0;j<T;j++)
			{
				par_cen = mu_z[indices_bloc[i]*T+j]*mu_z[indices_bloc[i]*T+j];
			}
			par_cen = par_cen/(sigma*sigma);
			par_h = 1. - 2./3.*(T+par_cen)*(T+3.*par_cen) / ((T+2*par_cen)*(T+2*par_cen));
			par_p = (T+2*par_cen) / ((T+par_cen)*(T+par_cen));
			par_m = (par_h -1)*(1-3*par_h);
			
			mass_0 = normcdf( ( pow(thresh*thresh/(sigma*sigma) / (T+par_cen),par_h) - 1 - par_h*par_p*(par_h - 1 - par_m*par_p*(1-0.5*par_h)) ) / (par_h*sqrt(2*par_p*(1+par_m*par_p))  ) );
			
			log_q_zx = log_q_zx + log(mass_0);
		}
	}
	
	/* computation of log(pi(Z)) */
	log_pi_Z = log_pi(Z,size_mZ);
	
	
	/* computation of the acceptance probability */
	alpha = log_pi_Z + log_q_zx - log_pi_X[0] - log_q_xz;
	
	/* printf("log pi z = %f \n", log_pi_Z);
	printf("log pi x = %f \n", log_pi_X[0]);
	printf("log q z x = %f \n", log_q_zx);
	printf("log q x z = %f \n", log_q_xz); */
	
	/* acceptance/rejection step */
	acc = 0;
	if (log(gsl_rng_uniform(r)) < alpha)
	{
		acc = 1;
		log_pi_X[0] = log_pi_Z;
		size_mX[0] = size_mZ;
		for(i=0;i<P;i++)
		{
			for(j=0;j<T;j++)
			{
				X[i*T+j] = Z[i*T+j];
			}
		}
	}
	
	/* save data if the burn-in period is finished */
	if (n>=B)
	{		
		for(i=0;i<P;i++)
		{
			for(j=0;j<T;j++)
			{
				mean_X[i+j*P] = (mean_X[i+j*P] * (n-B) + X[i*T+j]) / (n-B+1);
				mean_mod[i+j*P] = (mean_mod[i+j*P] * (n-B) + (double) (X[i*T+j] !=0) ) / (n-B+1);
			}
		}
		acceptation[n-B] = (double) acc;
	}
	return;
	

	
}

/* 2 : move associated with the proximal operator */

void pmala_move(int n, double* X, double* log_pi_X, int* size_mX)
{	
	/* definition and allocation */
	int i,j;

	int size_block_temp = 0;
	int new_index_block, test_index, size_mZ, act_row;
	
	double c_trunc_grad_x, c_trunc_grad_z, norm2_Zi, norm2_Xi, shrink, acc, log_pi_Z, alpha;
	double log_q_xz, log_q_zx, par_cen, par_h, par_p, par_m, mass_0, norm2_gzc, g_u;
		
	/* auxiliary computations */
	cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,P,T,P,1.0,GtG,P,X,T,0.0,GtGx,T);
	/* dgemm(&notrans,&notrans,&P,&T,&P,&alpha,GtG,&P,X,&P,&beta,GtGx,&P); */
	
	/* selection of the indices of the components to be updated */
	
	if(size_block < P)
	{
		new_index_block = floor(gsl_rng_uniform(r) * P);
		indices_bloc[size_block_temp] = new_index_block;
		size_block_temp += 1;
		
		while(size_block_temp<size_block)
		{
			/* sample a new index */
			new_index_block = floor(gsl_rng_uniform(r) * P);
			
			/* test if the new index was already selected */
			test_index = 0;
			for(i=0;i<size_block_temp;i++)
			{
				if(new_index_block == indices_bloc[i])
				{
					test_index = 1;
				}
			}
			
			/* add the new index if not already selected */
			if(test_index==0)
			{
				indices_bloc[size_block_temp] = new_index_block;
				size_block_temp += 1;
			}
		}
	}
	else
	{
		for(i=0;i<P;i++)
		{
			indices_bloc[i] = i;
		}
	}
	
	/* computation of the truncation constant for the gradient */
	c_trunc_grad_x = 0;
	for(i=0;i<P;i++)
	{
		for(j=0;j<T;j++)
		{
			c_trunc_grad_x = c_trunc_grad_x + (GtY[i*T+j] - GtGx[i*T+j]) * (GtY[i*T+j] - GtGx[i*T+j]);
		}
	}
	
	c_trunc_grad_x = sqrt(c_trunc_grad_x)/tau;
	c_trunc_grad_x = MAX(c_trunc_grad_x,trunc_grad);
	c_trunc_grad_x = trunc_grad/c_trunc_grad_x;
	
	/* computation of the proposed point before noise + shrinkage */
	for(i=0;i<P;i++)
	{
		for(j=0;j<T;j++)
		{
			mu_x[i*T+j] = X[i*T+j];
			Z[i*T+j] = X[i*T+j];
		}
	}
	
	for(i=0;i<size_block;i++)
	{
		for(j=0;j<T;j++)
		{
			mu_x[indices_bloc[i]*T+j] = mu_x[indices_bloc[i]*T+j] + pas_grad/tau*c_trunc_grad_x * (GtY[indices_bloc[i]*T+j]-GtGx[indices_bloc[i]*T+j]);
			
			Z[indices_bloc[i]*T+j] = mu_x[indices_bloc[i]*T+j];
		}
	}
	
	/* noise + shrinkage of the proposed point */
	for(i=0;i<size_block;i++)
	{
		/* add noise */
		norm2_Zi = 0.;
		for(j=0;j<T;j++)
		{
			Z[indices_bloc[i]*T+j] = Z[indices_bloc[i]*T+j] + sigma * gsl_ran_gaussian(r);
			norm2_Zi = norm2_Zi + Z[indices_bloc[i]*T+j]*Z[indices_bloc[i]*T+j];
		}
		
		/* computation of the shrinkage constant */
		shrink = 1. - thresh/sqrt(norm2_Zi);
		if(shrink<=0 || norm2_Zi==0)
		{
			shrink = 0.;
		}
		
		/* shrinkage */
		for(j=0;j<T;j++)
		{
			Z[indices_bloc[i]*T+j] = Z[indices_bloc[i]*T+j] * shrink;
		}		
	}	
	
	/* computations of Gt*G*z */
	cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,P,T,P,1.0,GtG,P,Z,T,0.0,GtGz,T);
	/* dgemm(&notrans,&notrans,&P,&T,&P,&alpha,GtG,&P,Z,&P,&beta,GtGz,&P); */
	
	/* computation of the truncation constant for the gradient in z */
	c_trunc_grad_z = 0;
	for(i=0;i<P;i++)
	{
		for(j=0;j<T;j++)
		{
			c_trunc_grad_z = c_trunc_grad_z + (GtY[i*T+j] - GtGz[i*T+j]) * (GtY[i*T+j] - GtGz[i*T+j]);
		}
	}
	
	c_trunc_grad_z = sqrt(c_trunc_grad_z)/tau;
	c_trunc_grad_z = MAX(c_trunc_grad_z,trunc_grad);
	c_trunc_grad_z = trunc_grad/c_trunc_grad_z;
	
	/* computation of mu(z) for the updated row indices */
	
	for(i=0;i<size_block;i++)
	{
		for(j=0;j<T;j++)
		{
			mu_z[indices_bloc[i]*T+j] = Z[indices_bloc[i]*T+j] + pas_grad/tau*c_trunc_grad_z * (GtY[indices_bloc[i]*T+j]-GtGz[indices_bloc[i]*T+j]);
		}
	}
	
	/* computation of log(q(x,z))  and log(q(z,x)) */
	
	log_q_xz = 0.;
	log_q_zx = 0.;
	size_mZ = size_mX[0];
	
	for(i=0;i<size_block;i++)
	{
		/* computation of log(q(x,z)) */
		act_row = 1;
		norm2_Zi = 0;
		for(j=0;j<T;j++)
		{
			act_row = act_row * (int)(Z[indices_bloc[i]*T+j] == 0);
			norm2_Zi = norm2_Zi + Z[indices_bloc[i]*T+j]*Z[indices_bloc[i]*T+j];
		}
		act_row = 1-act_row;
		size_mZ = size_mZ + (int)(act_row);
		
		if(act_row)
		{
			g_u = 1+thresh/sqrt(norm2_Zi);
			norm2_gzc = 0.;
			for(j=0;j<T;j++)
			{				
				norm2_gzc = norm2_gzc +  (g_u * Z[indices_bloc[i]*T+j] - mu_x[indices_bloc[i]*T+j]) * (g_u * Z[indices_bloc[i]*T+j] - mu_x[indices_bloc[i]*T+j]);
			}
			log_q_xz = log_q_xz + T*log(g_u/sqrt(2*pi*sigma*sigma)) -log(g_u) -1./(2.*sigma*sigma)*norm2_gzc;
		}
		else
		{
			par_cen = 0;
			for(j=0;j<T;j++)
			{
				par_cen = mu_x[indices_bloc[i]*T+j]*mu_x[indices_bloc[i]*T+j];
			}
			par_cen = par_cen/(sigma*sigma);
			par_h = 1. - 2./3.*(T+par_cen)*(T+3.*par_cen) / ((T+2*par_cen)*(T+2*par_cen));
			par_p = (T+2*par_cen) / ((T+par_cen)*(T+par_cen));
			par_m = (par_h -1)*(1-3*par_h);
			
			mass_0 = normcdf( ( pow(thresh*thresh/(sigma*sigma) / (T+par_cen),par_h) - 1 - par_h*par_p*(par_h - 1 - par_m*par_p*(1-0.5*par_h)) ) / (par_h*sqrt(2*par_p*(1+par_m*par_p))  ) );
			
			log_q_xz = log_q_xz + log(mass_0);
		}
		
		
		/* computation of log(q(z,x)) */
		act_row = 1;
		norm2_Xi = 0;
		for(j=0;j<T;j++)
		{
			act_row = act_row * (int)(X[indices_bloc[i]*T+j] == 0);
			norm2_Xi = norm2_Xi + X[indices_bloc[i]*T+j]*X[indices_bloc[i]*T+j];
		}
		act_row = 1-act_row;
		size_mZ = size_mZ - (int)(act_row);
		
		if(act_row)
		{
			g_u = 1+thresh/sqrt(norm2_Xi);
			norm2_gzc = 0.;
			for(j=0;j<T;j++)
			{
				
				norm2_gzc = norm2_gzc +  (g_u * X[indices_bloc[i]*T+j] - mu_z[indices_bloc[i]*T+j]) * (g_u * X[indices_bloc[i]*T+j] - mu_z[indices_bloc[i]*T+j]);
			}
			log_q_zx = log_q_zx + T*log(g_u/sqrt(2*pi*sigma*sigma)) -log(g_u) -1./(2.*sigma*sigma)*norm2_gzc;
		}
		else
		{
			par_cen = 0;
			for(j=0;j<T;j++)
			{
				par_cen = mu_z[indices_bloc[i]*T+j]*mu_z[indices_bloc[i]*T+j];
			}
			par_cen = par_cen/(sigma*sigma);
			par_h = 1. - 2./3.*(T+par_cen)*(T+3.*par_cen) / ((T+2*par_cen)*(T+2*par_cen));
			par_p = (T+2*par_cen) / ((T+par_cen)*(T+par_cen));
			par_m = (par_h -1)*(1-3*par_h);
			
			mass_0 = normcdf( ( pow(thresh*thresh/(sigma*sigma) / (T+par_cen),par_h) - 1 - par_h*par_p*(par_h - 1 - par_m*par_p*(1-0.5*par_h)) ) / (par_h*sqrt(2*par_p*(1+par_m*par_p))  ) );
			
			log_q_zx = log_q_zx + log(mass_0);
		}
	}

	
	
	/* computation of log(pi(Z)) */

	log_pi_Z = log_pi(Z,size_mZ);
	
	/* computation of the acceptance probability */
	 alpha = log_pi_Z + log_q_zx - log_pi_X[0] - log_q_xz; 
	
	/* acceptance/rejection step */
	acc = 0;
	if (log(gsl_rng_uniform(r)) < alpha)
	{
		acc = 1;
		log_pi_X[0] = log_pi_Z;
		size_mX[0] = size_mZ;
		for(i=0;i<P;i++)
		{
			for(j=0;j<T;j++)
			{
				X[i*T+j] = Z[i*T+j];
			}
		}
	}
	
	/* save data if the burn-in period is finished */
	if (n>=B)
	{		
		for(i=0;i<P;i++)
		{
			for(j=0;j<T;j++)
			{
				mean_X[i+j*P] = (mean_X[i+j*P] * (n-B) + X[i*T+j]) / (n-B+1);
				mean_mod[i+j*P] = (mean_mod[i+j*P] * (n-B) + (double) (X[i*T+j] !=0) ) / (n-B+1);
			}
		}
		acceptation[n-B] = (double) acc;
	}
	return;
	

	
}

/* 3 : move associated with the hard thresholding operator */

void htmala_move(int n, double* X, double* log_pi_X, int* size_mX)
{	
	/* definition and allocation */
	int i,j;
	
	int size_block_temp = 0;
	int new_index_block, test_index, size_mZ, act_row;
	
	double c_trunc_grad_x, c_trunc_grad_z, norm2_Zi, norm2_Xi, shrink, acc, log_pi_Z, alpha;
	double log_q_xz, log_q_zx, par_cen, par_h, par_p, par_m, mass_0, norm2_gzc, g_u;

	/* auxiliary computations */
	cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,P,T,P,1.0,GtG,P,X,T,0.0,GtGx,T);
	/* dgemm(&notrans,&notrans,&P,&T,&P,&alpha,GtG,&P,X,&P,&beta,GtGx,&P); */
	
	/* selection of the indices of the components to be updated */
	
	if(size_block < P)
	{
		new_index_block = floor(gsl_rng_uniform(r) * P);
		indices_bloc[size_block_temp] = new_index_block;
		size_block_temp += 1;
		
		while(size_block_temp<size_block)
		{
			/* sample a new index */
			new_index_block = floor(gsl_rng_uniform(r) * P);
			
			/* test if the new index was already selected */
			test_index = 0;
			for(i=0;i<size_block_temp;i++)
			{
				if(new_index_block == indices_bloc[i])
				{
					test_index = 1;
				}
			}
			
			/* add the new index if not already selected */
			if(test_index==0)
			{
				indices_bloc[size_block_temp] = new_index_block;
				size_block_temp += 1;
			}
		}
	}
	else
	{
		for(i=0;i<P;i++)
		{
			indices_bloc[i] = i;
		}
	}
	
	/* computation of the truncation constant for the gradient */
	c_trunc_grad_x = 0;
	for(i=0;i<P;i++)
	{
		for(j=0;j<T;j++)
		{
			c_trunc_grad_x = c_trunc_grad_x + (GtY[i*T+j] - GtGx[i*T+j]) * (GtY[i*T+j] - GtGx[i*T+j]);
		}
	}
	
	c_trunc_grad_x = sqrt(c_trunc_grad_x)/tau;
	c_trunc_grad_x = MAX(c_trunc_grad_x,trunc_grad);
	c_trunc_grad_x = trunc_grad/c_trunc_grad_x;
	
	/* computation of the proposed point before noise + shrinkage */
	for(i=0;i<P;i++)
	{
		for(j=0;j<T;j++)
		{
			mu_x[i*T+j] = X[i*T+j];
			Z[i*T+j] = X[i*T+j];
		}
	}
	
	for(i=0;i<size_block;i++)
	{
		for(j=0;j<T;j++)
		{
			mu_x[indices_bloc[i]*T+j] = mu_x[indices_bloc[i]*T+j] + pas_grad/tau*c_trunc_grad_x * (GtY[indices_bloc[i]*T+j]-GtGx[indices_bloc[i]*T+j]);
			
			Z[indices_bloc[i]*T+j] = mu_x[indices_bloc[i]*T+j];
		}
	}
	
	/* noise + shrinkage of the proposed point */
	for(i=0;i<size_block;i++)
	{
		/* add noise */
		norm2_Zi = 0.;
		for(j=0;j<T;j++)
		{
			Z[indices_bloc[i]*T+j] = Z[indices_bloc[i]*T+j] + sigma * gsl_ran_gaussian(r);
			norm2_Zi = norm2_Zi + Z[indices_bloc[i]*T+j]*Z[indices_bloc[i]*T+j];
		}
		
		/* computation of the shrinkage constant */
		shrink = 1. - thresh/sqrt(norm2_Zi);
		if(shrink<=0 || norm2_Zi==0)
		{
			shrink = 0.;
		}
		else
		{
			shrink = 1.0;
		}
		
		/* shrinkage */
		for(j=0;j<T;j++)
		{
			Z[indices_bloc[i]*T+j] = Z[indices_bloc[i]*T+j] * shrink;
		}		
	}	
	
	/* computations of Gt*G*z */
	cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,P,T,P,1.0,GtG,P,Z,T,0.0,GtGz,T);
	/* dgemm(&notrans,&notrans,&P,&T,&P,&alpha,GtG,&P,Z,&P,&beta,GtGz,&P); */
	
	/* computation of the truncation constant for the gradient in z */
	c_trunc_grad_z = 0;
	for(i=0;i<P;i++)
	{
		for(j=0;j<T;j++)
		{
			c_trunc_grad_z = c_trunc_grad_z + (GtY[i*T+j] - GtGz[i*T+j]) * (GtY[i*T+j] - GtGz[i*T+j]);
		}
	}
	
	c_trunc_grad_z = sqrt(c_trunc_grad_z)/tau;
	c_trunc_grad_z = MAX(c_trunc_grad_z,trunc_grad);
	c_trunc_grad_z = trunc_grad/c_trunc_grad_z;
	
	/* computation of mu(z) for the updated row indices */
	
	for(i=0;i<size_block;i++)
	{
		for(j=0;j<T;j++)
		{
			mu_z[indices_bloc[i]*T+j] = Z[indices_bloc[i]*T+j] + pas_grad/tau*c_trunc_grad_z * (GtY[indices_bloc[i]*T+j]-GtGz[indices_bloc[i]*T+j]);
		}
	}
	
	/* computation of log(q(x,z))  and log(q(z,x)) */
	
	log_q_xz = 0.;
	log_q_zx = 0.;
	size_mZ = size_mX[0];
	
	for(i=0;i<size_block;i++)
	{
		/* computation of log(q(x,z)) */
		act_row = 1;
		norm2_Zi = 0;
		for(j=0;j<T;j++)
		{
			act_row = act_row * (int)(Z[indices_bloc[i]*T+j] == 0);
			norm2_Zi = norm2_Zi + Z[indices_bloc[i]*T+j]*Z[indices_bloc[i]*T+j];
		}
		act_row = 1-act_row;
		size_mZ = size_mZ + (int)(act_row);
		
		if(act_row)
		{
			g_u = (double)(norm2_Zi>thresh);
			norm2_gzc = 0.;
			for(j=0;j<T;j++)
			{				
				norm2_gzc = norm2_gzc +  (Z[indices_bloc[i]*T+j] - mu_x[indices_bloc[i]*T+j]) * (Z[indices_bloc[i]*T+j] - mu_x[indices_bloc[i]*T+j]);
			}
			log_q_xz = log_q_xz -T/2.0 * log(2*pi*sigma*sigma) -1./(2.*sigma*sigma)*norm2_gzc + log(g_u);
		}
		else
		{
			par_cen = 0;
			for(j=0;j<T;j++)
			{
				par_cen = mu_x[indices_bloc[i]*T+j]*mu_x[indices_bloc[i]*T+j];
			}
			par_cen = par_cen/(sigma*sigma);
			par_h = 1. - 2./3.*(T+par_cen)*(T+3.*par_cen) / ((T+2*par_cen)*(T+2*par_cen));
			par_p = (T+2*par_cen) / ((T+par_cen)*(T+par_cen));
			par_m = (par_h -1)*(1-3*par_h);
			
			mass_0 = normcdf( ( pow(thresh*thresh/(sigma*sigma) / (T+par_cen),par_h) - 1 - par_h*par_p*(par_h - 1 - par_m*par_p*(1-0.5*par_h)) ) / (par_h*sqrt(2*par_p*(1+par_m*par_p))  ) );
			
			log_q_xz = log_q_xz + log(mass_0);
		}
				
		/* computation of log(q(z,x)) */
		act_row = 1;
		norm2_Xi = 0;
		for(j=0;j<T;j++)
		{
			act_row = act_row * (int)(X[indices_bloc[i]*T+j] == 0);
			norm2_Xi = norm2_Xi + X[indices_bloc[i]*T+j]*X[indices_bloc[i]*T+j];
		}
		act_row = 1-act_row;
		size_mZ = size_mZ - (int)(act_row);
		
		if(act_row)
		{
			g_u = (double)(norm2_Xi>thresh);
			norm2_gzc = 0.;
			for(j=0;j<T;j++)
			{
				
				norm2_gzc = norm2_gzc +  (X[indices_bloc[i]*T+j] - mu_z[indices_bloc[i]*T+j]) * (X[indices_bloc[i]*T+j] - mu_z[indices_bloc[i]*T+j]);
			}
			log_q_zx = log_q_zx -T/2.0 *log(2*pi*sigma*sigma) -1./(2.*sigma*sigma)*norm2_gzc +log(g_u);
		}
		else
		{
			par_cen = 0;
			for(j=0;j<T;j++)
			{
				par_cen = mu_z[indices_bloc[i]*T+j]*mu_z[indices_bloc[i]*T+j];
			}
			par_cen = par_cen/(sigma*sigma);
			par_h = 1. - 2./3.*(T+par_cen)*(T+3.*par_cen) / ((T+2*par_cen)*(T+2*par_cen));
			par_p = (T+2*par_cen) / ((T+par_cen)*(T+par_cen));
			par_m = (par_h -1)*(1-3*par_h);
			
			mass_0 = normcdf( ( pow(thresh*thresh/(sigma*sigma) / (T+par_cen),par_h) - 1 - par_h*par_p*(par_h - 1 - par_m*par_p*(1-0.5*par_h)) ) / (par_h*sqrt(2*par_p*(1+par_m*par_p))  ) );
			
			log_q_zx = log_q_zx + log(mass_0);
		}
	}	
	
	/* computation of log(pi(Z)) */
	log_pi_Z = log_pi(Z,size_mZ);
	
	/* computation of the acceptance probability */
	 alpha = log_pi_Z + log_q_zx - log_pi_X[0] - log_q_xz; 
	
	/* acceptance/rejection step */
	acc = 0;
	if (log(gsl_rng_uniform(r)) < alpha)
	{
		acc = 1;
		log_pi_X[0] = log_pi_Z;
		size_mX[0] = size_mZ;
		for(i=0;i<P;i++)
		{
			for(j=0;j<T;j++)
			{
				X[i*T+j] = Z[i*T+j];
			}
		}
	}
	
	/* save data if the burn-in period is finished */
	if (n>=B)
	{		
		for(i=0;i<P;i++)
		{
			for(j=0;j<T;j++)
			{
				mean_X[i+j*P] = (mean_X[i+j*P] * (n-B) + X[i*T+j]) / (n-B+1);
				mean_mod[i+j*P] = (mean_mod[i+j*P] * (n-B) + (double) (X[i*T+j] !=0) ) / (n-B+1);
			}
		}
		acceptation[n-B] = (double) acc;
	}
	return;
}

/* ------------------------ main function ----------------------------*/

void stmala_fun()
{
	/* definition and allocation */
	int i,j,n;
	double *X, *log_pi_X;
	int *size_mX;
	int test_act_row;
	
	/* utile si dgemm
	alpha   = 1.0;
    beta    = 0.0;
    trans   = 'T';
    notrans = 'N'; */
	
	X = malloc(P*T*sizeof(double));
	log_pi_X = malloc(1*sizeof(double));
	size_mX = malloc(1*sizeof(int));
	
	
	/* auxiliary computations */
	
	GtY = malloc(P * T * sizeof(double));
	GtG = malloc(P * P * sizeof(double));

	/* dgemm(&trans,&notrans,&P,&T,&N,&alpha,G,&N,Y,&N,&beta,GtY,&P);
	dgemm(&trans,&notrans,&P,&P,&N,&alpha,G,&N,G,&N,&beta,GtG,&P); */
	cblas_dgemm(CblasRowMajor, CblasTrans, CblasNoTrans,P,T,N,1.0,G,P,Y,T,0.0,GtY,T);
	cblas_dgemm(CblasRowMajor, CblasTrans, CblasNoTrans,P,P,N,1.0,G,P,G,P,0.0,GtG,P);
	
	pas_grad = sigma*sigma/2;
	
	GtGx = malloc(P*T * sizeof(double));
	GtGz = malloc(P*T * sizeof(double));
	indices_bloc = malloc(size_block * sizeof(int));
	mu_x = malloc(P*T* sizeof(double));
	mu_z = malloc(P*T* sizeof(double));
	Z = malloc(P*T* sizeof(double));
	Gx = malloc(N*T*sizeof(double));
	
	/* initialization */
	size_mX[0] = 0;
	for(i=0;i<P;i++)
	{
		test_act_row = 1;
		for(j=0;j<T;j++)
		{
			X[i*T+j] = init[i*T+j];
			test_act_row = test_act_row * (int)(X[i*T+j] == 0);
		}
		test_act_row = 1 - test_act_row;
		if(test_act_row)
		{
			size_mX[0] += 1;
		}
	}
	
	log_pi_X[0] = log_pi(X,size_mX[0]);
	
	/* Entering loop... */
	
	if(st_fun==1)
	{
		for(n=0;n<(nb_it+B);n++)
		{
			/* move */
			pmala_move(n,X,log_pi_X,size_mX);
		}
	}
	else
	{
		if(st_fun==2)
		{
			for(n=0;n<(nb_it+B);n++)
			{
				/* move */
				htmala_move(n,X,log_pi_X,size_mX);
			}
		}
		else
		{
			for(n=0;n<(nb_it+B);n++)
			{
				/* move */
				stmala_move(n,X,log_pi_X,size_mX);
			}
		}
	}
		
	/* free */
	
	free(X);
	free(log_pi_X);
	free(size_mX); 
	free(mu_x);
	free(mu_z);
	free(Z);
	free(GtGx);
	free(GtGz);
	free(indices_bloc);
	free(Gx); 
	
	return;
}


/* ------------------------- mex function ----------------------------*/


void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{
	/* initializing random generator */	
	struct timeval tv;
	gettimeofday(&tv,0);
	gsl_rng_default_seed = tv.tv_sec + tv.tv_usec;
    r = gsl_rng_alloc (gsl_rng_default);	
    
    /* Check for proper number of arguments */
    if (nrhs != 18) { 
	mexErrMsgTxt("18 input arguments required."); 
    } else if (nlhs > 3) {
	mexErrMsgTxt("Too many output arguments."); 
    } 

	/* Read arguments into proper C variable */	
    B = (int) (*mxGetPr(B_IN));
    nb_it = (int) (*mxGetPr(nb_it_IN));  
    N = (int) (*mxGetPr(N_IN));
    P = (int) (*mxGetPr(P_IN));
    T = (int) (*mxGetPr(T_IN));   
    Y = mxGetPr(Y_IN);
    G = mxGetPr(G_IN);
    tau = (double) (*mxGetPr(tau_IN)); 
    c_pen = (double) (*mxGetPr(c_pen_IN)); 
    c_pen_elast = (double) (*mxGetPr(c_pen_elast_IN)); 
    c_lambda = (double) (*mxGetPr(c_lambda_IN));  
    par_prior_w = (double) (*mxGetPr(par_prior_w_IN));   
    st_fun = (int) (*mxGetPr(st_fun_IN));
    init = mxGetPr(init_IN); 
    sigma = (double) (*mxGetPr(sigma_IN)); 
    thresh = (double) (*mxGetPr(thresh_IN)); 
    trunc_grad = (double) (*mxGetPr(trunc_grad_IN));
    size_block = (int) (*mxGetPr(size_block_IN));
    
	
    /* Create a matrix for the return argument */ 
    mean_X_OUT = mxCreateDoubleMatrix(P,T, mxREAL); 
    mean_X = mxGetPr(mean_X_OUT);
    mean_mod_OUT = mxCreateDoubleMatrix(P,T, mxREAL); 
    mean_mod = mxGetPr(mean_mod_OUT);    
    acceptation_OUT = mxCreateDoubleMatrix(nb_it,1, mxREAL); 
    acceptation =  mxGetPr(acceptation_OUT);
    
    /* call main function, and return */   
    printf("Calling main function...\n");
    
    stmala_fun();
    
    gsl_rng_free(r); 
    return;    
}
