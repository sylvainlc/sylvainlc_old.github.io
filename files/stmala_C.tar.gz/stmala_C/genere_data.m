% script to generate regression data from various examples

% ------------- model dim 16 non correlated design ------------- %

% generate data :

% G=randn(100,16);
% 
% E = randn(100,1);
% 
% X = zeros(16,1);
% X(1:8) = 1;
% 
% % save data :
% 
% save('G_16i.dat','G')
% save('E_16i.dat','E')
% save('X_16i.dat','X')


% ------------- model dim 16 correlated design - hard ------------- %

% example inspired from Petralias and Dellaportas

% % generate data :
%
% G=zeros(100,16);
% 
% G(:,1)=1;
% G(:,2:13) = randn(100,12);
% u = randn(100,1);
% G(:,14) = sum(G(:,1:4),2) + u;
% G(:,15) = sum(G(:,5:7),2) + u;
% G(:,16) = sum(G(:,2:7),2) + u;
% 
% E = randn(100,1);
% 
% X = zeros(16,1);
% X(1:8) = 1;
% 
% % save data :
%
% save('G_16c.dat','G')
% save('E_16c.dat','E')
% save('X_16c.dat','X')


% ------------- model dim 200 non correlated design ------------- %

% example taken from Rigollet and Tsybakov

% % generate data :
%
% P = 200;
% N = 100;
% S = 10;

% G = randn(N,P);
% E = randn(N,1);
% X = [1*ones(S,1);zeros(P-S,1)];

% % save data :
%
%save('G_rt.dat','G')
%save('E_rt.dat','E')
%save('X_rt.dat','X')


% ------------- model dim 200 correlated design ------------- %

% example inspired from Breiman

% % generate data :
%
% P = 200;
% N = 100;
% 
% mcov = zeros(P,P);
% for i=1:P
%     for j=1:P
%         mcov(i,j) = 0.3^abs(i-j);
%     end
% end
% 
% G = randn(N,P)*chol(mcov);
% E = randn(N,1);
% 
% X = zeros(P,1);
% 
% for k=1:4
%     X(50*(k-1)+(1:5)) = (-1)^(k-1)*[1 2 3 4 5].^(1/k);
% end
% 
% % save data :
%
% save('G_bre.dat','G')
% save('E_bre.dat','E')
% save('X_bre.dat','X')



% ------------- model dim 16 correlated design ------------- %

% % generate data :
% 
% G=randn(100,16);
% G(:,2:7) = repmat(G(:,1),1,6) + 0.05*randn(100,6);
% 
% E = randn(100,1);
% 
% X = zeros(16,1);
% X(4) = 1;
% 
% % save data :
% 
% save('G_16ag.dat','G')
% save('E_16ag.dat','E')
% save('X_16ag.dat','X')






