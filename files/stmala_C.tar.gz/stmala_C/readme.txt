A) Introduction :


This is the help file for the C version of stmala. It contains the list of files that can be found in this folder and a list of the arguments required by stmala.m. 
For an illustrative example, see the example file (example_stmala_C.m).

Please note that it is required to compile stmala.c before running it. The compiling command is in compile.m.



B) List of files in this folder :


1) Example of use of stmala (with examples of arguments) 

- example_stmala_C.m

2) Algorithm

- main function : stmala.c

3) Auxiliary files

- compile.m : file containing the command to compile the stmala.c file in matlab or octave.
- genere_data.m : script to generate data from various examples. Uncomment the desired example
- E_16i, G_16i and X_16i : an example of simulated data (used in example_stmala_matlab.m)
- readme.txt : this file



C) List of arguments for stmala.m (an illustrative example is in example_stmala_matlab.m)


% - looop size - %

   B : burn-in size
   nb_it : number of iterations

% - dimensions - %

   N : number of observations
   P : number of regressors
   T : number of time steps

% - model - %

   Y : obervations vector
   G : design matrix
   tau : observation noise

% - target distribution - %

   c_pen : penality constant in the target distribution
   c_pen_elast : elastic penality constant in the target distribution
   c_lambda : renormalizing constant
   par_prior_w : parameter of the Bernouilli prior on the models

% - parameters for stmala - %

   st_fun : choice of the shrinkage-thresholding operator
   init : initial point
   c_sigma : standard deviation of the proposal distribution
   thresh : threshold (gamma)
   trunc_grad : level of truncation for the gradient
   size_block : size of the block to be updated
