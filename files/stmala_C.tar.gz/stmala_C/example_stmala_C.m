% script to test stmala with matlab or octave

% please, run compile.m once before using this script

% examples of regression data can be generated from genere_data.m

clear all

% -------------------- load and generate data ----------------------- %

% load in matlab
load('G_16i.dat','-mat')
load('E_16i.dat','-mat')
load('X_16i.dat','-mat')

% % load in octave
% load G_16i.dat
% load E_16i.dat
% load X_16i.dat

% dimensions
P = length(G(1,:));
N = length(G(:,1));
T= length(X(1,:));

% observation noise
tau = 1;

% compute observations
Y = G*X+ sqrt(tau)*E;

% lipschitz constant
L = norm(G * G')/(tau); 

% --------------------------- parameters ---------------------------- %


% --- loop size --- %

% burn-in size
B = 1;
% number of iterations
nb_it = 1000000;

% --- parameters of stmala --- %

% sigma (standard deviation in the proposal)
c_sigma = 1*sqrt(2/L);
% truncation constant for the gradient
trunc_grad = 100;
% block size
taille_bloc = 4;
% threshold
seuil = 0.12;
% choice of the operator (1 for prox, 2 for ht, 3 for stvs)
fct_seuil=3;

% --- parameters of the target distribution --- %

% penalty constant
c_pen = 1.0;
% elastic penalty constant
c_pen_elast = 0.0;
% Bernouilli parameter in the prior on m
par_prior_w = 0.1;

% --- initialization --- %
init = zeros(P,T);

% -------------------- auxiliary computations ------------------------ %

 % renormalizing constant
 if (c_pen==0)
    c_lambda=1;
else
    c_lambda = 2*pi^(T/2)*(1/c_pen)^T*factorial(T-1)/gamma(T/2);
 end

G_mex = [];
Y_mex = [];
for i=1:N
    G_mex= [G_mex G(i,:)];
    Y_mex = [Y_mex Y(i,:)];
end

init_mex=[];
for i=1:P
    init_mex = [init_mex init(i,:)];
end

% ----------------------------- stmala -------------------------------- %


[x_moy,mod_moy,accept] = stmala(B,nb_it,N,P,T,Y_mex,G_mex,tau,c_pen,c_pen_elast,c_lambda,par_prior_w,fct_seuil,init_mex,c_sigma,seuil,trunc_grad,taille_bloc);

% ----------------------------- plot -------------------------------- %

acceptance_rate = cumsum(accept')./(1:nb_it)*100;

figure(1)
clf
plot(1:nb_it,acceptance_rate,'-b','LineWidth',2)
title('evolution of the acceptance rate')

figure(2)
clf
bar(x_moy)
title('mean regression vector')

figure(3)
clf
bar(mod_moy)
title('activation probabilities')












