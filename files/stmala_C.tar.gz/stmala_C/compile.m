% script to compile stmala.c for matlab or octave

% in matlab :
 mex -v -lgsl -lgslcblas -lblas stmala.c -L/usr/lib/gcc/x86_64-linux-gnu/4.3/
 
 % in octave :
 % mex -v -lgsl -lgslcblas -lblas stmala.c
